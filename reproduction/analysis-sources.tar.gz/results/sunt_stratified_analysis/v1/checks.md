# Verificações numéricas e de procedência

1748 verificações; 0 falharam.

| verificação | ok | detalhe |
|---|---|---|
| configuração results/sunt_centralized_boardings/sunt/seed_007/metrics.json | sim | method=centralized, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_centralized_boardings/sunt/seed_007/metrics.json | sim |  |
| configuração results/sunt_centralized_boardings/sunt/seed_042/metrics.json | sim | method=centralized, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_centralized_boardings/sunt/seed_042/metrics.json | sim |  |
| configuração results/sunt_centralized_boardings/sunt/seed_101/metrics.json | sim | method=centralized, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_centralized_boardings/sunt/seed_101/metrics.json | sim |  |
| configuração results/sunt_centralized_boardings/sunt/seed_123/metrics.json | sim | method=centralized, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_centralized_boardings/sunt/seed_123/metrics.json | sim |  |
| configuração results/sunt_centralized_boardings/sunt/seed_314/metrics.json | sim | method=centralized, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_centralized_boardings/sunt/seed_314/metrics.json | sim |  |
| configuração results/sunt_fedavg_final/sunt/k006/seed_007/metrics.json | sim | method=fedavg_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedavg_final/sunt/k006/seed_007/metrics.json | sim |  |
| configuração results/sunt_fedavg_final/sunt/k006/seed_042/metrics.json | sim | method=fedavg_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedavg_final/sunt/k006/seed_042/metrics.json | sim |  |
| configuração results/sunt_fedavg_final/sunt/k006/seed_101/metrics.json | sim | method=fedavg_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedavg_final/sunt/k006/seed_101/metrics.json | sim |  |
| configuração results/sunt_fedavg_final/sunt/k006/seed_123/metrics.json | sim | method=fedavg_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedavg_final/sunt/k006/seed_123/metrics.json | sim |  |
| configuração results/sunt_fedavg_final/sunt/k006/seed_314/metrics.json | sim | method=fedavg_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedavg_final/sunt/k006/seed_314/metrics.json | sim |  |
| configuração results/sunt_fedavg_final/sunt/k020/seed_007/metrics.json | sim | method=fedavg_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedavg_final/sunt/k020/seed_007/metrics.json | sim |  |
| configuração results/sunt_fedavg_final/sunt/k020/seed_042/metrics.json | sim | method=fedavg_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedavg_final/sunt/k020/seed_042/metrics.json | sim |  |
| configuração results/sunt_fedavg_final/sunt/k020/seed_101/metrics.json | sim | method=fedavg_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedavg_final/sunt/k020/seed_101/metrics.json | sim |  |
| configuração results/sunt_fedavg_final/sunt/k020/seed_123/metrics.json | sim | method=fedavg_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedavg_final/sunt/k020/seed_123/metrics.json | sim |  |
| configuração results/sunt_fedavg_final/sunt/k020/seed_314/metrics.json | sim | method=fedavg_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedavg_final/sunt/k020/seed_314/metrics.json | sim |  |
| configuração results/sunt_fedavg_final/sunt/k166/seed_007/metrics.json | sim | method=fedavg_0hop, alvo=n_boardings, W/H=168/24, concluído=1000/1000 |
| hash igual ao provenance results/sunt_fedavg_final/sunt/k166/seed_007/metrics.json | sim |  |
| configuração results/sunt_fedavg_final/sunt/k166/seed_042/metrics.json | sim | method=fedavg_0hop, alvo=n_boardings, W/H=168/24, concluído=1000/1000 |
| hash igual ao provenance results/sunt_fedavg_final/sunt/k166/seed_042/metrics.json | sim |  |
| configuração results/sunt_fedavg_final/sunt/k166/seed_101/metrics.json | sim | method=fedavg_0hop, alvo=n_boardings, W/H=168/24, concluído=1000/1000 |
| hash igual ao provenance results/sunt_fedavg_final/sunt/k166/seed_101/metrics.json | sim |  |
| configuração results/sunt_fedavg_final/sunt/k166/seed_123/metrics.json | sim | method=fedavg_0hop, alvo=n_boardings, W/H=168/24, concluído=1000/1000 |
| hash igual ao provenance results/sunt_fedavg_final/sunt/k166/seed_123/metrics.json | sim |  |
| configuração results/sunt_fedavg_final/sunt/k166/seed_314/metrics.json | sim | method=fedavg_0hop, alvo=n_boardings, W/H=168/24, concluído=1000/1000 |
| hash igual ao provenance results/sunt_fedavg_final/sunt/k166/seed_314/metrics.json | sim |  |
| configuração results/sunt_fedgnnhet_final/sunt/k006/halo_1hop/seed_007/metrics.json | sim | method=fedgnnhet_1hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedgnnhet_final/sunt/k006/halo_1hop/seed_007/metrics.json | sim |  |
| configuração results/sunt_fedgnnhet_final/sunt/k006/halo_1hop/seed_042/metrics.json | sim | method=fedgnnhet_1hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedgnnhet_final/sunt/k006/halo_1hop/seed_042/metrics.json | sim |  |
| configuração results/sunt_fedgnnhet_final/sunt/k006/halo_1hop/seed_101/metrics.json | sim | method=fedgnnhet_1hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedgnnhet_final/sunt/k006/halo_1hop/seed_101/metrics.json | sim |  |
| configuração results/sunt_fedgnnhet_final/sunt/k006/halo_1hop/seed_123/metrics.json | sim | method=fedgnnhet_1hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedgnnhet_final/sunt/k006/halo_1hop/seed_123/metrics.json | sim |  |
| configuração results/sunt_fedgnnhet_final/sunt/k006/halo_1hop/seed_314/metrics.json | sim | method=fedgnnhet_1hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedgnnhet_final/sunt/k006/halo_1hop/seed_314/metrics.json | sim |  |
| configuração results/sunt_fedgnnhet_final/sunt/k020/halo_1hop/seed_007/metrics.json | sim | method=fedgnnhet_1hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedgnnhet_final/sunt/k020/halo_1hop/seed_007/metrics.json | sim |  |
| configuração results/sunt_fedgnnhet_final/sunt/k020/halo_1hop/seed_042/metrics.json | sim | method=fedgnnhet_1hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedgnnhet_final/sunt/k020/halo_1hop/seed_042/metrics.json | sim |  |
| configuração results/sunt_fedgnnhet_final/sunt/k020/halo_1hop/seed_101/metrics.json | sim | method=fedgnnhet_1hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedgnnhet_final/sunt/k020/halo_1hop/seed_101/metrics.json | sim |  |
| configuração results/sunt_fedgnnhet_final/sunt/k020/halo_1hop/seed_123/metrics.json | sim | method=fedgnnhet_1hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedgnnhet_final/sunt/k020/halo_1hop/seed_123/metrics.json | sim |  |
| configuração results/sunt_fedgnnhet_final/sunt/k020/halo_1hop/seed_314/metrics.json | sim | method=fedgnnhet_1hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedgnnhet_final/sunt/k020/halo_1hop/seed_314/metrics.json | sim |  |
| configuração results/sunt_fedgnnhet_final/sunt/k166/halo_1hop/seed_007/metrics.json | sim | method=fedgnnhet_1hop, alvo=n_boardings, W/H=168/24, concluído=1000/1000 |
| hash igual ao provenance results/sunt_fedgnnhet_final/sunt/k166/halo_1hop/seed_007/metrics.json | sim |  |
| configuração results/sunt_fedgnnhet_final/sunt/k166/halo_1hop/seed_042/metrics.json | sim | method=fedgnnhet_1hop, alvo=n_boardings, W/H=168/24, concluído=1000/1000 |
| hash igual ao provenance results/sunt_fedgnnhet_final/sunt/k166/halo_1hop/seed_042/metrics.json | sim |  |
| configuração results/sunt_fedgnnhet_final/sunt/k166/halo_1hop/seed_101/metrics.json | sim | method=fedgnnhet_1hop, alvo=n_boardings, W/H=168/24, concluído=1000/1000 |
| hash igual ao provenance results/sunt_fedgnnhet_final/sunt/k166/halo_1hop/seed_101/metrics.json | sim |  |
| configuração results/sunt_fedgnnhet_final/sunt/k166/halo_1hop/seed_123/metrics.json | sim | method=fedgnnhet_1hop, alvo=n_boardings, W/H=168/24, concluído=1000/1000 |
| hash igual ao provenance results/sunt_fedgnnhet_final/sunt/k166/halo_1hop/seed_123/metrics.json | sim |  |
| configuração results/sunt_fedgnnhet_final/sunt/k166/halo_1hop/seed_314/metrics.json | sim | method=fedgnnhet_1hop, alvo=n_boardings, W/H=168/24, concluído=1000/1000 |
| hash igual ao provenance results/sunt_fedgnnhet_final/sunt/k166/halo_1hop/seed_314/metrics.json | sim |  |
| configuração results/sunt_fedprox_final/sunt/k006/mu0p01/seed_007/metrics.json | sim | method=fedprox_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedprox_final/sunt/k006/mu0p01/seed_007/metrics.json | sim |  |
| configuração results/sunt_fedprox_final/sunt/k006/mu0p01/seed_042/metrics.json | sim | method=fedprox_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedprox_final/sunt/k006/mu0p01/seed_042/metrics.json | sim |  |
| configuração results/sunt_fedprox_final/sunt/k006/mu0p01/seed_101/metrics.json | sim | method=fedprox_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedprox_final/sunt/k006/mu0p01/seed_101/metrics.json | sim |  |
| configuração results/sunt_fedprox_final/sunt/k006/mu0p01/seed_123/metrics.json | sim | method=fedprox_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedprox_final/sunt/k006/mu0p01/seed_123/metrics.json | sim |  |
| configuração results/sunt_fedprox_final/sunt/k006/mu0p01/seed_314/metrics.json | sim | method=fedprox_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedprox_final/sunt/k006/mu0p01/seed_314/metrics.json | sim |  |
| configuração results/sunt_fedprox_final/sunt/k020/mu0p01/seed_007/metrics.json | sim | method=fedprox_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedprox_final/sunt/k020/mu0p01/seed_007/metrics.json | sim |  |
| configuração results/sunt_fedprox_final/sunt/k020/mu0p01/seed_042/metrics.json | sim | method=fedprox_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedprox_final/sunt/k020/mu0p01/seed_042/metrics.json | sim |  |
| configuração results/sunt_fedprox_final/sunt/k020/mu0p01/seed_101/metrics.json | sim | method=fedprox_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedprox_final/sunt/k020/mu0p01/seed_101/metrics.json | sim |  |
| configuração results/sunt_fedprox_final/sunt/k020/mu0p01/seed_123/metrics.json | sim | method=fedprox_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedprox_final/sunt/k020/mu0p01/seed_123/metrics.json | sim |  |
| configuração results/sunt_fedprox_final/sunt/k020/mu0p01/seed_314/metrics.json | sim | method=fedprox_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_fedprox_final/sunt/k020/mu0p01/seed_314/metrics.json | sim |  |
| configuração results/sunt_ditto_final/sunt/k006/lam_per_client/seed_007/metrics.json | sim | method=ditto_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_ditto_final/sunt/k006/lam_per_client/seed_007/metrics.json | sim |  |
| configuração results/sunt_ditto_final/sunt/k006/lam_per_client/seed_042/metrics.json | sim | method=ditto_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_ditto_final/sunt/k006/lam_per_client/seed_042/metrics.json | sim |  |
| configuração results/sunt_ditto_final/sunt/k006/lam_per_client/seed_101/metrics.json | sim | method=ditto_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_ditto_final/sunt/k006/lam_per_client/seed_101/metrics.json | sim |  |
| configuração results/sunt_ditto_final/sunt/k006/lam_per_client/seed_123/metrics.json | sim | method=ditto_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_ditto_final/sunt/k006/lam_per_client/seed_123/metrics.json | sim |  |
| configuração results/sunt_ditto_final/sunt/k006/lam_per_client/seed_314/metrics.json | sim | method=ditto_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_ditto_final/sunt/k006/lam_per_client/seed_314/metrics.json | sim |  |
| configuração results/sunt_ditto_final/sunt/k020/lam_per_client/seed_007/metrics.json | sim | method=ditto_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_ditto_final/sunt/k020/lam_per_client/seed_007/metrics.json | sim |  |
| configuração results/sunt_ditto_final/sunt/k020/lam_per_client/seed_042/metrics.json | sim | method=ditto_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_ditto_final/sunt/k020/lam_per_client/seed_042/metrics.json | sim |  |
| configuração results/sunt_ditto_final/sunt/k020/lam_per_client/seed_101/metrics.json | sim | method=ditto_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_ditto_final/sunt/k020/lam_per_client/seed_101/metrics.json | sim |  |
| configuração results/sunt_ditto_final/sunt/k020/lam_per_client/seed_123/metrics.json | sim | method=ditto_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_ditto_final/sunt/k020/lam_per_client/seed_123/metrics.json | sim |  |
| configuração results/sunt_ditto_final/sunt/k020/lam_per_client/seed_314/metrics.json | sim | method=ditto_0hop, alvo=n_boardings, W/H=168/24, concluído=600/600 |
| hash igual ao provenance results/sunt_ditto_final/sunt/k020/lam_per_client/seed_314/metrics.json | sim |  |
| grafo carregado = transit simétrico | sim |  |
| diagonal do grafo nula | sim |  |
| timestamps horários, únicos e consecutivos | sim |  |
| corte do treino = 1.ª origem de validação | sim | t_end=1528 (2024-05-03 16:00:00), 1.ª origem val=1528 |
| último alvo de treino antes do corte | sim | último alvo=1527 (2024-05-03 15:00:00) |
| alvos observados do treino finitos e ≥ 0 | sim |  |
| k=6: ordem dos nós da partição = série | sim |  |
| k=6: nº de clientes realizado | sim |  |
| k=6: node_indices por cliente = client_assignments | sim |  |
| k=6: fronteira só de saída = 0 (grafo simétrico) | sim | 0 nós |
| k=20: ordem dos nós da partição = série | sim |  |
| k=20: nº de clientes realizado | sim |  |
| k=20: node_indices por cliente = client_assignments | sim |  |
| k=20: fronteira só de saída = 0 (grafo simétrico) | sim | 0 nós |
| k=166: ordem dos nós da partição = série | sim |  |
| k=166: nº de clientes realizado | sim |  |
| k=166: node_indices por cliente = client_assignments | sim |  |
| k=166: fronteira só de saída = 0 (grafo simétrico) | sim | 0 nós |
| test Centralizado k=None s=7: per_node com 2903 nós reais | sim |  |
| test Centralizado k=None s=7: erros finitos e ≥ 0 | sim |  |
| test Centralizado k=None s=7: contagens = Centralizado s=7 | sim |  |
| test Centralizado k=None s=7: nós sem alvo têm erro 0 | sim |  |
| test Centralizado k=None s=7: Σerro/Σcount reproduz MAE gravado | sim | 3.947531307 vs 3.947531307 |
| test Centralizado k=None s=7: Σcount = observations | sim |  |
| test Centralizado k=None s=7 k=6: recomposição dos estratos = MAE global | sim |  |
| test Centralizado k=None s=7 k=20: recomposição dos estratos = MAE global | sim |  |
| test Centralizado k=None s=7 k=166: recomposição dos estratos = MAE global | sim |  |
| test Centralizado k=None s=42: per_node com 2903 nós reais | sim |  |
| test Centralizado k=None s=42: erros finitos e ≥ 0 | sim |  |
| test Centralizado k=None s=42: contagens = Centralizado s=7 | sim |  |
| test Centralizado k=None s=42: nós sem alvo têm erro 0 | sim |  |
| test Centralizado k=None s=42: Σerro/Σcount reproduz MAE gravado | sim | 3.950957723 vs 3.950957723 |
| test Centralizado k=None s=42: Σcount = observations | sim |  |
| test Centralizado k=None s=42 k=6: recomposição dos estratos = MAE global | sim |  |
| test Centralizado k=None s=42 k=20: recomposição dos estratos = MAE global | sim |  |
| test Centralizado k=None s=42 k=166: recomposição dos estratos = MAE global | sim |  |
| test Centralizado k=None s=101: per_node com 2903 nós reais | sim |  |
| test Centralizado k=None s=101: erros finitos e ≥ 0 | sim |  |
| test Centralizado k=None s=101: contagens = Centralizado s=7 | sim |  |
| test Centralizado k=None s=101: nós sem alvo têm erro 0 | sim |  |
| test Centralizado k=None s=101: Σerro/Σcount reproduz MAE gravado | sim | 3.935280649 vs 3.935280649 |
| test Centralizado k=None s=101: Σcount = observations | sim |  |
| test Centralizado k=None s=101 k=6: recomposição dos estratos = MAE global | sim |  |
| test Centralizado k=None s=101 k=20: recomposição dos estratos = MAE global | sim |  |
| test Centralizado k=None s=101 k=166: recomposição dos estratos = MAE global | sim |  |
| test Centralizado k=None s=123: per_node com 2903 nós reais | sim |  |
| test Centralizado k=None s=123: erros finitos e ≥ 0 | sim |  |
| test Centralizado k=None s=123: contagens = Centralizado s=7 | sim |  |
| test Centralizado k=None s=123: nós sem alvo têm erro 0 | sim |  |
| test Centralizado k=None s=123: Σerro/Σcount reproduz MAE gravado | sim | 3.937683509 vs 3.937683510 |
| test Centralizado k=None s=123: Σcount = observations | sim |  |
| test Centralizado k=None s=123 k=6: recomposição dos estratos = MAE global | sim |  |
| test Centralizado k=None s=123 k=20: recomposição dos estratos = MAE global | sim |  |
| test Centralizado k=None s=123 k=166: recomposição dos estratos = MAE global | sim |  |
| test Centralizado k=None s=314: per_node com 2903 nós reais | sim |  |
| test Centralizado k=None s=314: erros finitos e ≥ 0 | sim |  |
| test Centralizado k=None s=314: contagens = Centralizado s=7 | sim |  |
| test Centralizado k=None s=314: nós sem alvo têm erro 0 | sim |  |
| test Centralizado k=None s=314: Σerro/Σcount reproduz MAE gravado | sim | 3.936480525 vs 3.936480525 |
| test Centralizado k=None s=314: Σcount = observations | sim |  |
| test Centralizado k=None s=314 k=6: recomposição dos estratos = MAE global | sim |  |
| test Centralizado k=None s=314 k=20: recomposição dos estratos = MAE global | sim |  |
| test Centralizado k=None s=314 k=166: recomposição dos estratos = MAE global | sim |  |
| validation Centralizado k=None s=7: per_node com 2903 nós reais | sim |  |
| validation Centralizado k=None s=7: erros finitos e ≥ 0 | sim |  |
| validation Centralizado k=None s=7: contagens = Centralizado s=7 | sim |  |
| validation Centralizado k=None s=7: nós sem alvo têm erro 0 | sim |  |
| validation Centralizado k=None s=7: Σerro/Σcount reproduz MAE gravado | sim | 4.871948912 vs 4.871948912 |
| validation Centralizado k=None s=7: Σcount = observations | sim |  |
| validation Centralizado k=None s=7 k=6: recomposição dos estratos = MAE global | sim |  |
| validation Centralizado k=None s=7 k=20: recomposição dos estratos = MAE global | sim |  |
| validation Centralizado k=None s=7 k=166: recomposição dos estratos = MAE global | sim |  |
| validation Centralizado k=None s=42: per_node com 2903 nós reais | sim |  |
| validation Centralizado k=None s=42: erros finitos e ≥ 0 | sim |  |
| validation Centralizado k=None s=42: contagens = Centralizado s=7 | sim |  |
| validation Centralizado k=None s=42: nós sem alvo têm erro 0 | sim |  |
| validation Centralizado k=None s=42: Σerro/Σcount reproduz MAE gravado | sim | 4.991313709 vs 4.991313709 |
| validation Centralizado k=None s=42: Σcount = observations | sim |  |
| validation Centralizado k=None s=42 k=6: recomposição dos estratos = MAE global | sim |  |
| validation Centralizado k=None s=42 k=20: recomposição dos estratos = MAE global | sim |  |
| validation Centralizado k=None s=42 k=166: recomposição dos estratos = MAE global | sim |  |
| validation Centralizado k=None s=101: per_node com 2903 nós reais | sim |  |
| validation Centralizado k=None s=101: erros finitos e ≥ 0 | sim |  |
| validation Centralizado k=None s=101: contagens = Centralizado s=7 | sim |  |
| validation Centralizado k=None s=101: nós sem alvo têm erro 0 | sim |  |
| validation Centralizado k=None s=101: Σerro/Σcount reproduz MAE gravado | sim | 4.901576945 vs 4.901576944 |
| validation Centralizado k=None s=101: Σcount = observations | sim |  |
| validation Centralizado k=None s=101 k=6: recomposição dos estratos = MAE global | sim |  |
| validation Centralizado k=None s=101 k=20: recomposição dos estratos = MAE global | sim |  |
| validation Centralizado k=None s=101 k=166: recomposição dos estratos = MAE global | sim |  |
| validation Centralizado k=None s=123: per_node com 2903 nós reais | sim |  |
| validation Centralizado k=None s=123: erros finitos e ≥ 0 | sim |  |
| validation Centralizado k=None s=123: contagens = Centralizado s=7 | sim |  |
| validation Centralizado k=None s=123: nós sem alvo têm erro 0 | sim |  |
| validation Centralizado k=None s=123: Σerro/Σcount reproduz MAE gravado | sim | 4.886892299 vs 4.886892299 |
| validation Centralizado k=None s=123: Σcount = observations | sim |  |
| validation Centralizado k=None s=123 k=6: recomposição dos estratos = MAE global | sim |  |
| validation Centralizado k=None s=123 k=20: recomposição dos estratos = MAE global | sim |  |
| validation Centralizado k=None s=123 k=166: recomposição dos estratos = MAE global | sim |  |
| validation Centralizado k=None s=314: per_node com 2903 nós reais | sim |  |
| validation Centralizado k=None s=314: erros finitos e ≥ 0 | sim |  |
| validation Centralizado k=None s=314: contagens = Centralizado s=7 | sim |  |
| validation Centralizado k=None s=314: nós sem alvo têm erro 0 | sim |  |
| validation Centralizado k=None s=314: Σerro/Σcount reproduz MAE gravado | sim | 4.934840465 vs 4.934840465 |
| validation Centralizado k=None s=314: Σcount = observations | sim |  |
| validation Centralizado k=None s=314 k=6: recomposição dos estratos = MAE global | sim |  |
| validation Centralizado k=None s=314 k=20: recomposição dos estratos = MAE global | sim |  |
| validation Centralizado k=None s=314 k=166: recomposição dos estratos = MAE global | sim |  |

Verificações por (split, método, semente, k, dimensão) de cobertura dos estratos e de recomposição estão completas em `checks.json`.
