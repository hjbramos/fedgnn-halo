# SUNT — onde a partição prejudica e onde o halo recupera (análise estratificada v1)

**Natureza:** exploratória, motivada por resultados agregados já conhecidos; definições congeladas em
[`protocol.md`](protocol.md) antes do cálculo (SHA-256 verificado pelo script). Sem treino, sem
reavaliação, sem novos hiperparâmetros. Unidade de réplica = semente (n=5); IC95% `t` exploratório,
não ajustado. Δ em embarques/h (MAE de teste ponderado por alvos observados); negativo favorece o
primeiro método.

Reprodução: `conda activate fl_env && python -m experiments.sunt_stratified_analysis`
(tabelas completas em [`summary_tables.md`](summary_tables.md); dados em `contrasts.csv`,
`boundary_vs_interior.csv`, `strata_metrics.csv`; insumos e hashes em `manifest.json`).

## Insumos e verificações

- 55 execuções da campanha final (Centralizado 5; FedAvg e halo `1hop` 15 cada em k=6, 20, 166;
  FedProx μ=0,01 e Ditto 10 cada em k=6, 20). Todas com alvo `n_boardings`, entradas
  `n_boardings+n_alightings`, W168/H24, orçamento completo (600 épocas/rodadas; 1000 em k=166), clientes
  realizados = k, `per_node` em validação e teste, hash do `metrics.json` igual ao do
  `generated-traffic/provenance.json`. **Nenhuma lacuna**; nenhuma reavaliação foi necessária
  (os checkpoints não estão nesta máquina e não foram usados).
- 1748 verificações, 0 falhas ([`checks.md`](checks.md)): Σerro/Σcount reproduz o MAE gravado
  (tol. rel. 1e-6) e `observations`; contagens idênticas entre todos os métodos e sementes (mesmos
  alvos); recomposição dos estratos = MAE global (1e-9) em todas as dimensões; 2903 nós reais (nós
  virtuais do halo não entram); ordem dos nós da partição = série; `client_nodes` = partição; grafo
  simétrico com diagonal nula; **nenhum nó com fronteira só de saída**; nenhum nó sem entrada de
  vizinhos; nenhum nó sem observação de treino. 10 nós não têm alvo no teste (2893 avaliáveis).
  Garantia do código: se alguma verificação **registrada** for reprovada, o script grava só
  `audit_runs.csv` e `checks.*`, remove os arquivos de resultado anteriores e termina com erro. Essa
  proteção não cobre interrupções ou exceções inesperadas: um erro ocorrido durante a própria escrita
  pode deixar arquivos de execuções diferentes misturados. Nesse caso, a fonte de verdade é
  `manifest.json` (escrito por último), cujo `script_sha256` e o total de verificações devem conferir.
- Treino para descritores: horas < 2024-05-03 16:00 (1528 h, de 01/03 00:00 a 03/05 15:00, incluindo as 168 h que só aparecem como entrada),
  conferido contra a 1.ª origem de validação; células horárias únicas. Tercis: volume 2,17 / 9,32
  embarques/h (968/967/968 nós); cobertura 0,807 / 0,853 (975/963/965; 8 e 7 empates exatos nos
  limites, mantidos inteiros na faixa inferior). Três faixas efetivas em ambos.
- `per_node.count` conta ocorrências em janelas (cada célula repete-se até 24 vezes); as participações
  abaixo são de ocorrências, não de células únicas.

## Resultados observados

**Tamanho da fronteira.** Nós com ≥1 vizinho de entrada externo: 137 (k=6; 5,0 % dos alvos de teste),
288 (k=20; 10,5 %), 1016 (k=166; 36,1 %).

### 1. FedAvg − Centralizado: perda absoluta maior na fronteira e nos nós de alto volume

| k | fronteira | interior | fronteira − interior (por semente) |
|---|---|---|---|
| 6 | +0,171 ± 0,190 | +0,061 ± 0,060 | +0,110 ± 0,131; 4/5 positivas; IC [−0,05; +0,27] |
| 20 | +0,255 ± 0,064 | +0,118 ± 0,045 | +0,137 ± 0,038; 5/5; IC [+0,09; +0,18] |
| 166 | +0,742 ± 0,027 | +0,197 ± 0,012 | +0,545 ± 0,019; 5/5; IC [+0,52; +0,57] |

- Mesmo sinal na validação (fronteira − interior: +0,62, +0,40, +0,54; 5/5 em cada k).
- **Confusão com escala:** os nós de fronteira têm volume de treino ~3× maior (mediana 13,9 vs 4,3 em
  k=6; 9,5 vs 3,1 em k=166; 51–63 % no tercil alto vs 24–32 % no interior). Em termos relativos ao MAE
  do Centralizado no mesmo estrato (quantidade derivada, não prevista no protocolo), a perda do FedAvg é
  semelhante entre fronteira e interior em k=6 (2,0 % vs 1,6 %) e k=20 (3,6 % vs 3,3 %), e só em k=166 é
  claramente maior na fronteira (12,4 % vs 7,1 %).
- **Por fração do peso externo perdido (fig. 2):** a perda salta de `0` para qualquer faixa >0, mas
  **não cresce com a fração**: em k=166, +0,20 (0) → +1,13 (0;0,25] → +0,64 (0,25;0,50] → +0,53
  (0,50;1]; em k=20, +0,12 → +0,31 → +0,24 → +0,09. A faixa (0;0,25] reúne os nós de maior grau e
  volume (mediana de grau 5, volume 14–20), isto é, centros que perdem poucas de muitas arestas.
- **Volume e cobertura (fig. 3):** a perda é quase toda do tercil alto de volume (k=166: +0,96 vs +0,04
  no baixo; k=20: +0,33 vs +0,01). Cobertura mostra gradiente semelhante, mais fraco, coerente com sua
  associação ao volume.
- **Composição (fig. 4):** apesar do Δ maior na fronteira, o interior responde pela maior parte da
  perda global em k=6 (0,058 de 0,066) e k=20 (0,106 de 0,132); em k=166 a fronteira passa a dominar
  (0,268 de 0,394).

### 2. halo − FedAvg: sem evidência consistente de benefício adicional na fronteira

Duas perguntas distintas, com intervalos distintos: (a) o halo melhora a fronteira? (contraste na
fronteira); (b) melhora a fronteira **mais** que o interior? (diferença fronteira − interior, por semente).

| k | (a) fronteira: média ± dp; sem. < 0; IC95% t | interior | global | (b) fronteira − interior; sem. < 0; IC95% t |
|---|---|---|---|---|
| 6 | −0,133 ± 0,191; 4/5; [−0,371; +0,104] | −0,038 ± 0,058 (4/5) | −0,043 ± 0,064 (3/5) | −0,095 ± 0,136; 4/5; [−0,265; +0,074] |
| 20 | −0,015 ± 0,058; 3/5; [−0,088; +0,057] | −0,005 ± 0,060 (3/5) | −0,006 ± 0,059 (3/5) | −0,011 ± 0,026; 4/5; [−0,043; +0,022] |
| 166 | −0,006 ± 0,060; 3/5; [−0,081; +0,068] | −0,007 ± 0,017 (3/5) | −0,007 ± 0,032 (3/5) | +0,000 ± 0,046; 3/5; [−0,056; +0,057] |

- **k=6:** melhora média observada de −0,133 na fronteira, incerta (IC inclui zero) e muito influenciada
  por uma semente (s42: −0,46; as demais entre −0,11 e +0,02). s42 é também a pior semente do FedAvg
  (+0,17 sobre o Centralizado no global), e o dp entre sementes de halo − Centralizado (0,008) é menor
  que o de FedAvg − Centralizado (0,066). Isso é compatível com o halo reduzir a variabilidade entre
  sementes, mas **não identifica o mecanismo**.
- **Composição do ganho em k=6:** o interior responde por −0,036 do Δ global de −0,043 (84 %), mas
  representa 95 % dos alvos; a contribuição grande decorre sobretudo do peso do estrato, com melhora por
  alvo menor que a da fronteira. O halo não altera as mensagens do interior, mas altera o treinamento
  (os nós de fronteira mudam o gradiente e, portanto, os parâmetros compartilhados), então um efeito
  indireto no interior é possível. Esse número não distingue benefício indireto de variabilidade.
- **k=20 e k=166:** médias pequenas em todos os estratos, sinais divididos entre sementes. Na fronteira
  de k=166 (36 % dos alvos, 1016 nós), a média de −0,006 é pequena frente à perda de +0,74 do FedAvg,
  mas o IC [−0,081; +0,068] não exclui efeitos dessa ordem.
- **Perda de peso, volume, cobertura:** nenhuma faixa mostra benefício consistente que cresça com a
  fração perdida. As faixas com padrão de sinal constante são minúsculas ou de magnitude desprezível:
  k=6 (0,50;1] (5 nós, 0,2 % dos alvos) com halo pior em 5/5 (+0,14); tercil baixo de volume em k=6
  com −0,015 (5/5). Não interpretamos essas células.
- **Validação:** em k=20 a diferença (b) é −0,050 (5/5; IC [−0,097; −0,004]), contra −0,011 (4/5) no
  teste. A validação também orientou a escolha do checkpoint de cada execução e cobre ~9 dias; não a
  tratamos como confirmação.

### 3. halo − Centralizado e métodos secundários

- A distância residual do halo ao Centralizado na fronteira é de +0,24 (k=20) e +0,74 (k=166), próxima
  à do FedAvg. Em k=6 é +0,038, com a ressalva de variabilidade acima.
- **Ditto − FedAvg** (k=20): na fronteira, **+0,042 ± 0,064; IC [−0,037; +0,121]; melhora em 2/5
  sementes**; no interior, −0,015 (2/5). A diferença (b) é +0,057 ± 0,038 (0/5; IC [+0,010; +0,103]): é
  uma diferença **entre efeitos** na fronteira e no interior, não uma piora da fronteira em todas as
  sementes. Em k=6, fronteira −0,069 (3/5; IC [−0,253; +0,115]).
- **FedProx − FedAvg** (k=20): fronteira −0,040 ± 0,036 (5/5; IC [−0,084; +0,004]); (b) −0,025 (4/5;
  IC [−0,051; +0,001]). Em k=6, fronteira +0,034 (2/5).
- Esses resultados enfraquecem as configurações avaliadas de Ditto e FedProx como soluções já
  demonstradas para a fronteira; não dizem nada sobre outras formas de personalização (por exemplo,
  representação compartilhada com saída local). Todos exploratórios e sem ajuste.
- As correlações por cliente do `results/sunt_report/clientes.md` (Spearman entre peso externo e perda,
  ρ≈+0,5 em k=20 e k=166) são associações entre clientes, coerentes com o observado aqui, sem valor
  causal; o mesmo ρ aparece para FedAvg e halo.

## Respostas às perguntas

1. **O halo ajuda especificamente os nós que perderam mensagens de entrada?**
   *Observado:* não foi demonstrada recuperação consistente na fronteira nas configurações avaliadas.
   Em k=6 há melhora média de −0,133, incerta (IC [−0,371; +0,104]) e dependente de uma semente; em
   k=20 e k=166 as médias são pequenas (−0,015, IC [−0,088; +0,057]; −0,006, IC [−0,081; +0,068]). A diferença
   fronteira − interior também não se afasta de zero no teste em nenhum k.
   *Ainda não respondido:* com 5 sementes, os dados são compatíveis com os efeitos na fronteira dentro
   dos intervalos exploratórios: k=6 [−0,371; +0,104], k=20 [−0,088; +0,057], k=166 [−0,081; +0,068]
   embarques/h (negativo favorece o halo).
2. **Há melhora localizada ocultada pelo MAE global?** *Observado:* não encontramos. As contribuições da
   fronteira ao Δ global do halo são −0,007 (k=6), −0,002 (k=20) e −0,002 (k=166). O sinal favorável de
   k=20 na validação aparece bem menor no teste.
3. **A perda frente ao Centralizado cresce com a fração ponderada de entrada externa?**
   *Observado:* aumenta de "sem perda de peso" para "alguma perda", mas não cresce de forma monotônica
   com a fração; as maiores perdas absolutas estão em nós com pequena fração perdida, alto grau e alto
   volume.
   *Interpretação plausível:* a escala do alvo explica boa parte da diferença absoluta em k=6 e k=20;
   em k=166 a perda relativa também é maior na fronteira.
4. **O padrão persiste entre sementes e k?** *Observado:* a perda absoluta do FedAvg na fronteira
   persiste (5/5 sementes em k=20 e k=166, teste e validação) e cresce com k. Em k=20 e k=166 o halo
   mostra diferenças médias pequenas e de sinal variável; em k=6 a melhora média depende de uma semente.
5. **Volume e cobertura ajudam a interpretar?** *Observado:* sim para a perda federada (concentrada no
   tercil alto de volume); não revelam subgrupo em que o halo ajude de forma consistente.
6. **Qual hipótese merece o próximo experimento?** Ver recomendação.

## Interpretação plausível (não demonstrada)

A perda absoluta do FedAvg cresce com k e é maior em nós de fronteira e de alto volume; o halo `1hop`
(exato para LEConv de uma camada) não mostrou redução consistente dessa perda. Essas observações são
compatíveis com mecanismos diferentes, que esta análise **não separa**:

- **Valor limitado das mensagens perdidas:** se a informação dos vizinhos externos agrega pouco à
  previsão desses nós, o halo teria pouco a recuperar.
- **Efeitos do treinamento federado:** clientes pequenos e heterogêneos (k=166: 4–34 nós por cliente) e
  a média de parâmetros podem penalizar nós de alto volume, que estão desproporcionalmente na fronteira;
  isso também explicaria perda no interior.
- **Escala e composição:** fronteira e volume estão associados; parte da diferença fronteira/interior
  pode refletir só a escala do alvo.

Nenhuma delas é identificada como dominante por estes dados.

## Limitações

- Exploratória e pós-hoc em relação aos resultados agregados; muitas células, nenhuma correção para
  multiplicidade; n=5 sementes. Nós dentro de uma semente não são independentes.
- Fronteira e volume são correlacionados; o protocolo não previa estratificação cruzada e ela não foi
  feita, então o efeito "fronteira" e o efeito "volume" não estão separados.
- A partição é uma só por k (Leiden, semente 42); a variação entre partições não foi medida.
- Faixas extremas de perda (0,50;1] têm 5–89 nós e participação ≤ 3,2 %.
- MAE ponderado por ocorrências em janelas: células próximas ao fim do período pesam menos (aparecem em
  menos janelas). O MAE médio entre nós (secundário, em `summary_tables.md`) dá o mesmo quadro qualitativo.
- As células rodaram em GPUs diferentes (L40S, A16, RTX 2060; ver `audit_runs.csv`), cada célula inteira
  numa máquina; o não determinismo do CUDA entra na variação entre sementes, e comparações entre
  células (por exemplo, halo k=20 na RTX 2060 vs FedAvg k=20 na L40S) incluem também essa diferença.

## Recomendação

A análise **motiva controles que distingam o valor das mensagens espaciais das diferenças introduzidas
pelo treinamento federado**; não autoriza encerrar a hipótese espacial nem abandonar personalização.
Próximos controles, todos centralizados, no SUNT com alvo `n_boardings`, o protocolo congelado do
Centralizado (600 épocas, 5 sementes) e a mesma estratificação, sem selecionar nada no teste:

1. **Centralizado sem as arestas entre clientes** (para cada k=6, 20, 166, removendo só as arestas
   cortadas pela partição): mede diretamente a sensibilidade às conexões de fronteira sem treinamento
   federado. Se a fronteira piorar de forma semelhante à do FedAvg, isso sustentaria a hipótese de que
   as mensagens cortadas contribuem para a perda, sem demonstrar que explicam toda a diferença; se
   piorar pouco, outras fontes (treinamento federado, escala) ganham peso como explicação, sem ficarem
   demonstradas.
2. **Centralizado sem arestas:** mede o valor líquido do grafo completo sob o mesmo protocolo. Não
   isola as mensagens perdidas pela partição, mas delimita quanto o grafo contribui no total. As
   execuções sem arestas existentes (`results/centralized_noedges/sunt`, `sunt_fixed/noedges`,
   `sunt_probe/noedges`) são todas do alvo `loading`, com `loading` na entrada, e **não servem**.

Ambos exigem treino novo no Terumo. Na mesma etapa, convém pré-registrar a separação entre fronteira e
volume (estrato cruzado ou perda relativa como métrica principal). Personalização continua como hipótese
aberta: as configurações avaliadas de Ditto não melhoraram a fronteira de forma consistente, o que não
se estende a outras formas (por exemplo, representação compartilhada com saída local).

**Redação sugerida para a conclusão:** "A perda absoluta do FedAvg frente ao centralizado é maior na
fronteira, especialmente em k=166, mas está associada também ao volume de embarques. O halo apresentou
pequenas diferenças médias em k=20 e k=166 e melhora incerta em k=6. Não encontramos evidência
consistente de benefício adicional na fronteira; isso não demonstra ausência de efeito nem identifica a
otimização como causa dominante. O próximo passo é avaliar o valor do grafo e das arestas cortadas
mediante controles centralizados."

Ficam como próximos passos, não iniciados: análise por horizonte, horário de pico, novos controles e
novos métodos.
