import os,sys,json,time,fcntl,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent;os.chdir(ROOT)
LOG=Path.home()/'controles_20261114/logs/completar_controles_20261114'
lock=(ROOT/'queue.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
def write(path,obj):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(obj,indent=2)+'\n');tmp.replace(path)
def status(state,**kw):
    write(ROOT/'status.json',dict(state=state,updated_unix=time.time(),completed=done,**kw))
def readlim():return json.loads((LOG/'dual_limits.json').read_text())
def eligible():
    s=json.loads((LOG/'campaign_status.json').read_text())
    if s.get('failed') or s['stage'] not in ('running','completed_pending_audit'):return None
    if s['stage']=='running':
        if time.time()-s['updated_unix']>90 or s['limits']['max_parallel']!=9:return None
        if len(s['active'])>9:return None
        r=s['resources']
        if r['cpu_busy_pct']>=65 or r['load1']>=36 or r['available_ram_gib']<32:return None
    active=list(s.get('active',{}).values())
    for gpu in sorted(range(5),key=lambda g:sum(j['gpu']==g for j in active)):
        own={j['pid'] for j in active if j['gpu']==gpu}
        if len(own)>1:continue
        values=subprocess.check_output(['nvidia-smi','-i',str(gpu),'--query-gpu=memory.free,utilization.gpu','--format=csv,noheader,nounits'],text=True).strip().split(',')
        pids=subprocess.check_output(['nvidia-smi','-i',str(gpu),'--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True)
        pids={int(p.strip()) for p in pids.splitlines() if p.strip().isdigit()}
        if int(values[0])>=8192 and int(values[1])<70 and pids.issubset(own):return gpu
    return None
done=[]
assert not (ROOT/'results').exists(),'No automatic restart'
lim=readlim();assert lim['max_parallel']==10
write(ROOT/'previous_limits.json',lim)
lim['max_parallel']=9;write(LOG/'dual_limits.json',lim)
try:
    for seed in [7,42,101,123,314]:
        gpu=None
        while gpu is None:
            status('waiting_slot',seed=seed)
            time.sleep(30);gpu=eligible()
        env={**os.environ,'CUDA_VISIBLE_DEVICES':str(gpu),'OMP_NUM_THREADS':'3','MKL_NUM_THREADS':'3','OPENBLAS_NUM_THREADS':'3'}
        with (ROOT/f'seed_{seed:03d}.log').open('w') as log:
            child=subprocess.Popen(['nice','-n','10',sys.executable,'-u','run_seed.py',str(seed)],stdout=log,stderr=subprocess.STDOUT,env=env)
            status('running',seed=seed,gpu=gpu,pid=child.pid)
            rc=child.wait()
        if rc:raise RuntimeError(f'seed {seed}: exit {rc}')
        done.append(seed)
    status('completed')
except Exception as e:
    status('failed',error=str(e));raise
finally:
    lim=readlim()
    if lim['max_parallel']==9:
        lim['max_parallel']=10;write(LOG/'dual_limits.json',lim)
