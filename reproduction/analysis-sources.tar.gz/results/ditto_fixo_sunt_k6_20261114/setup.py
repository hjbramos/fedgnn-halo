from pathlib import Path
import shutil,json,hashlib,sys,os
import yaml
root=Path.home()/'ditto_fixo_sunt_k6_20261114';src=Path.home()/'controles_20261114'
for name in ['experiments','federation','models','data_loader']:
    if not (root/name).exists():
        shutil.copytree(src/name,root/name,ignore=shutil.ignore_patterns('__pycache__'))
    for f in (src/name).rglob('*.py'):
        assert f.read_bytes()==(root/name/f.relative_to(src/name)).read_bytes()
if not (root/'data').exists():
    (root/'data').symlink_to((src/'data').resolve(),target_is_directory=True)
cfg=yaml.safe_load((src/'config/sunt_ditto_final.yaml').read_text())
cfg['seeds']=[7,42,101,123,314]
cfg['ditto'].update(num_clients=[5],**{'lambda':[0.01]},lambda_candidates=[0.01],local_only=False,evaluate_test=False,keep_last_checkpoint=True,max_rounds=600,patience=100000)
cfg['execution'].update(cpus_per_run=3,max_parallel=1)
cfg['output']='results'
(root/'config.yaml').write_text(yaml.safe_dump(cfg,sort_keys=False))
os.chdir(root);sys.path.insert(0,str(root))
from experiments.federated import partition_dir
p=partition_dir('sunt',5,42)
meta=json.loads((p/'metadata.json').read_text());assert meta['num_clients']==6
paths=[]
for name in ['experiments','federation','models','data_loader']:
    paths.extend((root/name).rglob('*.py'))
paths.extend(p.rglob('*'))
manifest={str(x.relative_to(root)):hashlib.sha256(x.read_bytes()).hexdigest() for x in paths if x.is_file()}
(root/'provenance.json').write_text(json.dumps(dict(source=str(src),data=str((root/'data').resolve()),partition=str(p),metadata=meta,sha256=manifest),indent=2))
print(json.dumps({'partition':str(p),'clients':meta['num_clients'],'config':cfg},indent=2))
