import os,sys,json,time,fcntl,subprocess,argparse
from pathlib import Path
ROOT=Path(__file__).resolve().parent
LOG=Path.home()/'controles_20261114/logs/completar_controles_20261114'
SEEDS=[7,42,101,123,314]
def write(path,data):
 tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(data,indent=2)+'\n');tmp.replace(path)
def proc(pid):
 try:
  p=Path('/proc')/str(pid);v=(p/'stat').read_text().split()
  return {'state':v[2],'start':v[21],'args':(p/'cmdline').read_bytes().split(b'\0')}
 except OSError:return None
def alive(j):
 p=proc(j['pid']);return p and p['state']!='Z' and p['start']==j['start']
def complete(seed):
 p=ROOT/'results/sunt/k006/lam0p01'/f'seed_{seed:03d}'/'metrics.json'
 if not p.exists():return False
 m=json.loads(p.read_text())
 return m.get('seed')==seed and m.get('rounds_completed')==600 and m.get('num_clients')==6 and m.get('lambda_candidates')==[.01] and m.get('client_lambda')==[.01]*6 and m.get('test_evaluated') is False and 'test' not in m

def resources():
 def ticks():
  v=list(map(int,Path('/proc/stat').read_text().splitlines()[0].split()[1:9]));return sum(v),v[3]+v[4]
 a=ticks();time.sleep(1);b=ticks()
 mem=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))/1024**2
 return {'cpu_busy_pct':100*(1-(b[1]-a[1])/max(1,b[0]-a[0])),'load1':os.getloadavg()[0],'available_ram_gib':mem}
def eligibility(active):
 res=resources();c=json.loads((LOG/'campaign_status.json').read_text())
 if c.get('failed') or c['stage'] not in ['running','completed_pending_audit']:return None,res
 if c['stage']=='running' and time.time()-c['updated_unix']>100:return None,res
 controls=[j for j in c.get('active',{}).values() if proc(j['pid']) and proc(j['pid'])['state']!='Z']
 if len(controls)+len(active)>=10 or res['cpu_busy_pct']>=65 or res['load1']>=36 or res['available_ram_gib']<32:return None,res
 jobs=controls+list(active.values())
 # Pack Ditto onto its existing GPU first where possible, retaining GPUs for controls.
 for gpu in sorted(range(5),key=lambda g:(not any(j['gpu']==g for j in active.values()),sum(j['gpu']==g for j in jobs))):
  own={j['pid'] for j in jobs if j['gpu']==gpu}
  if len(own)>=2:continue
  raw=subprocess.check_output(['nvidia-smi','-i',str(gpu),'--query-gpu=memory.free,utilization.gpu','--format=csv,noheader,nounits'],text=True).split(',')
  apps=subprocess.check_output(['nvidia-smi','-i',str(gpu),'--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True)
  pids={int(p.strip()) for p in apps.splitlines() if p.strip().isdigit()}
  if int(raw[0])>=8192 and int(raw[1])<70 and pids.issubset(own):return gpu,res
 return None,res

def main():
 os.chdir(ROOT)
 if '--check' in sys.argv:
  s=json.loads((ROOT/'status.json').read_text());j={k:s[k] for k in ['pid','seed','gpu']};j['start']=proc(j['pid'])['start']
  print(json.dumps({'eligible':eligibility({j['seed']:j}),'adopt':j}));return
 lock=(ROOT/'queue.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 adoption=json.loads((ROOT/'parallel_adoption.json').read_text());active={7:adoption['trainer']};assert alive(active[7])
 done=[];failed=[];pending=[42,101,123,314]
 for seed in pending:assert not (ROOT/'results/sunt/k006/lam0p01'/f'seed_{seed:03d}').exists()
 handles={};children={}
 while active or pending:
  for seed,j in list(active.items()):
   rc=children[seed].poll() if seed in children else None if alive(j) else 0
   if rc is None:continue
   if rc==0 and complete(seed):done.append(seed)
   else:failed.append(seed)
   if seed in handles:handles.pop(seed).close()
   del active[seed]
  gpu,res=eligibility(active)
  if pending and not failed and len(active)<5 and gpu is not None:
   seed=pending.pop(0);log=(ROOT/f'seed_{seed:03d}.log').open('x')
   env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),OMP_NUM_THREADS='3',MKL_NUM_THREADS='3',OPENBLAS_NUM_THREADS='3')
   p=subprocess.Popen(['nice','-n','10',sys.executable,'-u','run_seed.py',str(seed)],stdout=log,stderr=subprocess.STDOUT,env=env)
   active[seed]={'seed':seed,'pid':p.pid,'gpu':gpu,'start':proc(p.pid)['start']};children[seed]=p;handles[seed]=log
  write(ROOT/'status.json',{'state':'blocked_failure' if failed else 'running' if active else 'waiting_slot','scheduler':'parallel','updated_unix':time.time(),'completed':sorted(done),'active':list(active.values()),'pending':pending,'failed':failed,'resources':res,'limits':{'ditto_parallel':5,'total_trainers':10,'per_gpu':2,'max_cpu_busy_pct':65,'max_load1':36,'min_available_ram_gib':32,'min_free_gpu_mib':8192}})
  if failed and not active:raise RuntimeError(f'Failed seeds: {failed}')
  time.sleep(30)
 assert all(complete(s) for s in SEEDS)
 write(ROOT/'status.json',{'state':'completed','completed':SEEDS,'updated_unix':time.time(),'scheduler':'parallel'})
 lim=json.loads((LOG/'dual_limits.json').read_text())
 if lim['max_parallel']==5:lim['max_parallel']=10;write(LOG/'dual_limits.json',lim)
if __name__=='__main__':main()
