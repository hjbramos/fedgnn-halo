import os,json,hashlib,tempfile,shutil,copy,io,importlib.util
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import patch
import numpy as np
import torch
ROOT=Path(__file__).resolve().parent
os.chdir(ROOT)
torch.set_num_threads(1);torch.set_num_interop_threads(1)
from experiments import ditto as d
from experiments.train import load_config

def same(a,b):
 if torch.is_tensor(a):assert torch.equal(a,b)
 elif isinstance(a,np.ndarray):assert np.array_equal(a,b)
 elif isinstance(a,dict):
  assert a.keys()==b.keys()
  for k in a:same(a[k],b[k])
 elif isinstance(a,(list,tuple)):
  assert len(a)==len(b)
  for x,y in zip(a,b):same(x,y)
 else:assert a==b,(a,b)

report={}
record=json.loads((ROOT/'recovery_record.json').read_text())
backup=ROOT/'recovery_round332'
assert hashlib.sha256((backup/'last.pt').read_bytes()).hexdigest()==record['checkpoint_sha256']
old=torch.load(backup/'last.pt',map_location='cpu',weights_only=False)
best=torch.load(backup/'best_model.pt',map_location='cpu',weights_only=False)
assert old['round']==332 and len(old['history'])==332
assert best['best_round']==332 and best['validation_MAE']==old['best_mae']
same(best['personal'],old['personal']);same(best['global_state'],old['global_state'])
assert all(list(x)==[.01] for x in old['personal'])
current=torch.load(ROOT/'results/sunt/k006/lam0p01/seed_007/last.pt',map_location='cpu',weights_only=False)
assert current['round']>332
same(old['history'],current['history'][:332])
assert [row['round'] for row in current['history']]==list(range(1,current['round']+1))
assert current['best_mae']==min(row['validation_MAE'] for row in current['history'])
report['checkpoint']={'hash_verified':True,'round':332,'global_and_six_personal_models_present':True,'best_checkpoint_matches_round332':True,'current_round':current['round'],'history_prefix_unchanged':True,'rounds_contiguous':True,'best_mae_matches_history':True}
adoption=json.loads((ROOT/'parallel_adoption.json').read_text())
for name,h in adoption['unchanged_training_files'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==h
report['training_sources_and_config_unchanged']=True

# Exercise the real restoration path against a temporary copy, then stop BEFORE any training.
class StopBeforeTraining(Exception):pass
with tempfile.TemporaryDirectory() as temp:
 output=Path(temp)/'restore';folder=output/'sunt/k006/lam0p01/seed_007';folder.mkdir(parents=True)
 shutil.copy2(backup/'last.pt',folder/'last.pt');shutil.copy2(backup/'best_model.pt',folder/'best_model.pt')
 cfg=load_config(ROOT/'config.yaml');assert cfg['ditto']['evaluate_test'] is False
 original_loader=d.load_clients
 def loader(*args):
  assert tuple(args[-1])==('train','validation')
  return original_loader(*args)
 def capture(global_state,personal,clients,weights,make_model,make_optimizer,train_global,train_personal,local_epochs,batches_seen,personal_seen):
  same(global_state,old['global_state']);same(personal,old['personal'])
  same(torch.get_rng_state(),old['rng']['torch']);same(np.random.get_state(),old['rng']['numpy'])
  same([c.loaders['train'].generator.get_state() for c in clients],old['rng']['loaders'])
  assert batches_seen==old['batches_seen'] and personal_seen==old['batches_seen_personalized']
  assert len(clients)==6 and local_epochs==1
  model=make_model(clients[0]);opt=make_optimizer(model)
  assert type(opt) is torch.optim.Adam and len(opt.state)==0
  report['real_restore_path']={'models_exact':True,'torch_rng_exact':True,'numpy_rng_exact':True,'six_loader_rngs_exact':True,'counters_exact':True,'new_round_adam_empty_as_protocol':True,'no_training_performed':True,'no_test_loaded':True}
  raise StopBeforeTraining
 with patch.object(d,'load_clients',loader),patch.object(d,'ditto_round',capture):
  try:d.train_ditto('sunt',5,.01,7,cfg,'cpu',output=output,resume=True)
  except StopBeforeTraining:pass
  else:raise AssertionError('restoration hook not reached')

# Independent CPU synthetic comparison: uninterrupted versus checkpoint resume, FIXED lambda, validation only.
spec=importlib.util.spec_from_file_location('fixture',ROOT/'test_fixture.py');fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)
t=fixture.DittoResumeTests();t.setUp()
try:
 t.cfg['ditto'].update(evaluate_test=False,keep_last_checkpoint=True,local_epochs=1,lambda_candidates=[.01])
 evaluated=[];orig_eval=d.evaluate_personalized;orig_global=d.evaluate_federated
 def evaluate(*args,**kw):
  assert args[4]=='validation';evaluated.append(args[4]);return orig_eval(*args,**kw)
 def global_eval(*args,**kw):
  assert args[4]=='validation';return orig_global(*args,**kw)
 with patch.object(d,'evaluate_personalized',evaluate),patch.object(d,'evaluate_federated',global_eval),redirect_stdout(io.StringIO()):
  full=d.train_ditto('synthetic',2,.01,7,t.cfg,'cpu',output='full',resume=False)
  original_save=d._save_atomic
  def interrupted_save(obj,path):
   original_save(obj,path)
   if path.name=='last.pt' and obj['round']==2:raise RuntimeError('controlled interruption')
  with patch.object(d,'_save_atomic',interrupted_save):
   try:d.train_ditto('synthetic',2,.01,7,t.cfg,'cpu',output='resumed',resume=False)
   except RuntimeError as e:assert str(e)=='controlled interruption'
   else:raise AssertionError('not interrupted')
  resumed=d.train_ditto('synthetic',2,.01,7,t.cfg,'cpu',output='resumed',resume=True)
 for key in ['validation','validation_global','client_lambda','best_round','rounds_completed','test_evaluated']:same(full[key],resumed[key])
 a=torch.load(t.root/'full/synthetic/k002/lam0p01/seed_007/last.pt',weights_only=False)
 b=torch.load(t.root/'resumed/synthetic/k002/lam0p01/seed_007/last.pt',weights_only=False)
 for key in ['global_state','personal','rng','batches_seen','batches_seen_personalized','best_mae','stopping_reference','without_improvement']:same(a[key],b[key])
 same([{k:v for k,v in row.items() if k!='elapsed_s'} for row in a['history']],[{k:v for k,v in row.items() if k!='elapsed_s'} for row in b['history']])
 report['synthetic_fixed_lambda_resume']={'passed':True,'device':'cpu','rounds':4,'interruption_after_round':2,'parameters_rng_metrics_selection_exact':True,'validation_only':True}
finally:t.doCleanups()
report['passed']=True
(ROOT/'resume_audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
