import sys,json,os,importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parent;os.chdir(ROOT);sys.path.insert(0,str(ROOT))
import torch
torch.set_num_threads(2)
from experiments import ditto as d
from experiments.train import load_config
# Synthetic CPU check: fixed coefficient, one personal trajectory, no test split.
spec=importlib.util.spec_from_file_location('fixture',ROOT/'test_fixture.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
t=mod.DittoResumeTests();t.setUp()
try:
    t.cfg['ditto'].update(evaluate_test=False,keep_last_checkpoint=True)
    original=d.load_clients
    def guard(*args):
        assert tuple(args[-1])==('train','validation')
        return original(*args)
    d.load_clients=guard
    m=d.train_ditto('synthetic',2,0.01,42,t.cfg,'cpu',output='fixed',resume=False)
    assert m['lambda_candidates']==[0.01] and m['client_lambda']==[0.01,0.01]
    assert not m['test_evaluated'] and 'test' not in m
    state=torch.load(t.root/'fixed/synthetic/k002/lam0p01/seed_042/last.pt',weights_only=False)
    assert all(list(x)==[0.01] for x in state['personal'])
finally:t.doCleanups()
cfg=load_config('config.yaml');w=cfg['windows']['sunt']
data=d.load_experiment('sunt',w['input_steps'],w['horizon'],w['features'],w['target'])
p=d.partition_dir('sunt',5,42)
clients=d.load_clients(data,p,32,0,7,('train','validation'))
assert len(clients)==6 and all(set(c.loaders)=={'train','validation'} for c in clients)
report=dict(synthetic_fixed_lambda='passed',clients=len(clients),client_nodes=[c.nodes for c in clients],splits=['train','validation'],lambda_fixed=0.01,rounds=600,seeds=cfg['seeds'])
(ROOT/'preflight.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
