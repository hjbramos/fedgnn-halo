# Ditto com lambda fixo — SUNT, seis clientes

Autorizado em 14/11/2026: lambda 0,01 definido antes das execuções, sementes 7, 42, 101, 123 e 314, 600 rodadas completas. Apenas treino e validação. Um modelo global e um personalizado por cliente. A seleção do checkpoint continua pelo MAE micro de validação de todos os clientes. Não há seleção entre coeficientes.

Mantidos LEConv64, embarques e desembarques, janela168/horizonte24, Adam reiniciado, uma época local por rodada, lote32, taxa0,001, clip5, partição42. Pedido5 corresponde aos seis clientes reais, verificado na metadata. Isso não reproduz a seleção dinâmica original nem iguala o custo computacional ao FedAvg.

Execução isolada em ~/ditto_fixo_sunt_k6_20261114, código congelado a partir de ~/controles_20261114 e dados compartilhados somente para leitura. Proveniência em provenance.json. Resultados não substituem a campanha anterior.

Fila sequencial: reduz apenas o limite de novas admissões dos controles de10 para9, espera a conclusão natural de uma vaga, mantém no máximo dois processos por GPU e dez no total. Exige 8GiB livres, GPU abaixo70%, CPU abaixo65%, load abaixo36 e RAM livre32GiB. Não admite GPU com processos externos. Restaura limite10 ao finalizar. Não envia sinais nem reinicia controles. Sem retomada automática.
