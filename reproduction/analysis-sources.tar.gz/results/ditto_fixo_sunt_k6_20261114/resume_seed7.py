import sys,json,os
from pathlib import Path
ROOT=Path(__file__).resolve().parent
os.chdir(ROOT);sys.path.insert(0,str(ROOT))
import torch
from experiments import ditto as d
from experiments.train import load_config
torch.set_num_threads(3);torch.set_num_interop_threads(2)
cfg=load_config('config.yaml')
assert cfg['ditto']['evaluate_test'] is False
assert cfg['ditto']['local_only'] is False
assert cfg['ditto']['max_rounds']==600
original=d.load_clients
def guarded(data,pdir,batch,workers,seed,splits):
    assert tuple(splits)==('train','validation')
    clients=original(data,pdir,batch,workers,seed,splits)
    assert len(clients)==6
    return clients
d.load_clients=guarded
seed=int(sys.argv[1]);assert seed in [7,42,101,123,314]
assert seed==7 and (ROOT/'results/sunt/k006/lam0p01'/f'seed_{seed:03d}'/'last.pt').exists()
m=d.train_ditto('sunt',5,0.01,seed,cfg,'cuda',resume=True)
assert m['num_clients']==6 and m['rounds_completed']==600
assert m['lambda_candidates']==[0.01] and m['client_lambda']==[0.01]*6
assert m['test_evaluated'] is False and 'test' not in m
