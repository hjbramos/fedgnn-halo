# Controle centralizado do estado do Adam — desktop

Autorização: comparação centralizada no SUNT, Adam preservado versus reiniciado a cada época, sementes 7, 42 e 101, 100 épocas, apenas treino e validação. Sem acesso ao Terumo.

- Entradas: embarques e desembarques, com máscaras. Alvo: embarques.
- Mesmos dados, grafo completo, janelas 168/24, normalização do treino, LEConv 64, lote 32, Adam lr 0,001, eps padrão, clipping 5 e ausência de parada antecipada efetiva do diagnóstico anterior.
- Seis execuções novas, em sequência na RTX 2060, quatro threads de CPU. Cada par recebe a mesma semente.
- A única intervenção é `optimizer.state.clear()` no começo de cada época do braço reiniciado, zerando momentos e contadores. Os parâmetros, grupos do otimizador e gerador dos lotes permanecem inalterados. Não há scheduler.
- O teste sintético em CPU exige igualdade exata com um Adam recém-criado durante três épocas. O treino verifica os estados no início de cada época, a inicialização dos modelos e a igualdade dos estados do gerador de lotes entre os braços.
- O carregador recusa qualquer split diferente de treino ou validação. `evaluate_test: false` impede avaliação e gravação de métricas de teste.
- Checkpoint escolhido pelo menor MAE de validação. `last.pt` preservado para eventual extensão autorizada. O lançador desta campanha inicia do zero; retomada deve ser implementada e conferida antes de uso.
- Registros por braço: `metrics.json`, `history.csv`, checkpoints; auditoria por época, resumo e diferenças pareadas. Não se exige identidade numérica de execuções em GPU nem se presume que três sementes demonstrem efeito geral.
- Interpretação: sensibilidade do centralizado ao estado do Adam sob 100 épocas. Não decompõe sozinho a diferença entre FedAvg e centralizado.

Execução: `desktop-remote:/home/helder/diagnostico_adam_centralizado_desktop_20261114`.
Snapshot: cópia verificada do diagnóstico anterior, em diretório separado. `provenance.json` registra os hashes dos 102 arquivos de dados e código copiados.
Logs: `logs/campaign.log`. Estado: `status.json`. Resumo: `summary.json`. Pares: `paired_validation.json`.
