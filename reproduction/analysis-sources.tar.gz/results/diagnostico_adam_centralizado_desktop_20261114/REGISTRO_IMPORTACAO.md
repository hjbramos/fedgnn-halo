# Arquivamento do diagnóstico do Adam — 16/11/2026

Os seis treinos existentes foram copiados do desktop, sem novos treinamentos, alteração de configuração ou avaliação do teste. Foram preservados o script da execução, a configuração, a cópia dos módulos de código, o protocolo, a procedência, os históricos, as métricas de validação, as auditorias por época, o resumo e as diferenças pareadas.

Origem: `desktop-remote:/home/helder/diagnostico_adam_centralizado_desktop_20261114/`. Os hashes consultados diretamente na origem constam em `remote_hashes.json`. O script `verificar_registros.py` confere os arquivos copiados, as seis execuções de 100 épocas, os resumos, a seleção pela validação, os estados do Adam, a inicialização e os estados do gerador de lotes nos pares. Seu resultado fica em `verificacao_importacao.json`.

Os checkpoints `results/<braço>/sunt/seed_<semente>/best_model.pt` e `last.pt` permanecem no desktop, fora do Git; seus hashes estão no mesmo manifesto. Não foram necessários para esta conferência dos registros. Não foi feita reavaliação dos modelos.

O apêndice relata apenas a direção das diferenças de MAE e RMSE de validação nas sementes 7, 42 e 101. Os valores conferem com os registros existentes. O diagnóstico não integra as tabelas de teste, as famílias de Holm ou o pacote `generated-traffic`; arquivá-lo não modifica o pacote 1.27.1. A exportação principal continua vinculada ao commit de suas fontes, anterior a este arquivamento complementar.

Para conferir novamente: `python results/diagnostico_adam_centralizado_desktop_20261114/verificar_registros.py`. Esse comando lê os registros locais e grava apenas o relatório de conferência.
