"""Conferência dos registros copiados, sem treino ou avaliação de checkpoints."""
import csv
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def read(path):
    return json.loads((ROOT / path).read_text())

def check():
    hashes = read('remote_hashes.json')
    copied = 0
    for name, expected in hashes.items():
        if name.endswith('.pt'):
            continue
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
        copied += 1
    status = read('status.json')
    assert status['state'] == 'complete' and status['completed'] == status['total'] == 6
    summary = read('summary.json')
    assert len(summary) == 6
    paired = read('paired_validation.json')
    assert sorted(x['seed'] for x in paired) == [7, 42, 101]
    validation_deltas = []
    for seed in [7, 42, 101]:
        audits, metrics = {}, {}
        for arm in ['preservado', 'reiniciado']:
            folder = ROOT / 'results' / arm / 'sunt' / f'seed_{seed:03d}'
            m = json.loads((folder / 'metrics.json').read_text())
            h = list(csv.DictReader((folder / 'history.csv').open()))
            a = read(f'audit_{arm}_s{seed}.json')
            assert len(h) == len(a) == m['epochs_completed'] == 100
            assert not m['test_evaluated'] and 'test' not in m
            best = min(h, key=lambda r: float(r['validation_MAE']))
            assert int(best['epoch']) == m['best_epoch']
            assert math.isclose(float(best['validation_MAE']), m['validation']['MAE'], rel_tol=1e-9)
            validation_deltas.append(abs(float(best['validation_MAE']) - m['validation']['MAE']))
            s = [x for x in summary if x['arm'] == arm and x['seed'] == seed]
            assert len(s) == 1 and s[0]['best_epoch'] == m['best_epoch']
            for metric in ['MAE', 'RMSE']:
                assert s[0][metric] == m['validation'][metric]
            assert [x['epoch'] for x in a] == list(range(1, 101))
            if arm == 'reiniciado':
                assert all(x['states_at_epoch_start'] == 0 for x in a)
            else:
                assert all(x['states_at_epoch_start'] > 0 for x in a[1:])
            audits[arm], metrics[arm] = a, m
        assert audits['preservado'][0]['initial_model'] == audits['reiniciado'][0]['initial_model']
        assert [x['loader_rng'] for x in audits['preservado']] == [x['loader_rng'] for x in audits['reiniciado']]
        pair = next(x for x in paired if x['seed'] == seed)
        for metric in ['MAE', 'RMSE']:
            difference = metrics['reiniciado']['validation'][metric] - metrics['preservado']['validation'][metric]
            assert difference == pair[metric + '_reset_minus_preserved'] and difference > 0
    return {'arquivos_copiados_conferidos': copied, 'checkpoints_preservados_no_desktop': sum(n.endswith('.pt') for n in hashes),
            'MAE_historico_vs_registro_rtol': 1e-9, 'maior_diferenca_MAE_historico_vs_registro': max(validation_deltas),
            'execucoes': 6, 'sementes': [7, 42, 101], 'epocas': 100, 'teste_avaliado': False,
            'hashes_resumos_selecao_e_auditorias_conferidos': True,
            'MAE_e_RMSE_reiniciado_maiores_nos_tres_pares': True,
            'limite': 'Conferência dos registros existentes, sem repetir treinos ou reavaliar checkpoints.'}

if __name__ == '__main__':
    result = check()
    (ROOT / 'verificacao_importacao.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result, ensure_ascii=False))
