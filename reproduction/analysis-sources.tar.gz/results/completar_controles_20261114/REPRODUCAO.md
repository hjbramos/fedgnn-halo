# Procedência e reprodução — 16/11/2026

Escopo incorporado: 35 execuções de centralizado com arestas internas, SUNT k=6 e METR-LA/PEMS-BAY k=5,10,20. As outras 30 execuções da campanha não são incorporadas por este pacote. Métricas, históricos, configurações, protocolo, scripts e manifestos são versionados; checkpoints permanecem fora do Git.

## Arquivos preservados

- Servidor Terumo, raiz `/home/helder/controles_20261114`.
- Resultados: `results/completar_controles_20261114/<conjunto>_cut_k<k>/<conjunto>/seed_<semente>/`.
- `best_model.pt`: modelo selecionado pelo menor MAE de validação.
- `last.pt`: estado final para retomada; não substitui o modelo selecionado.
- Cópia local: os mesmos caminhos relativos neste repositório.
- `procedencia/remote_hashes.json`: SHA-256 dos 140 arquivos copiados (35 métricas, 35 históricos e 70 checkpoints). O manifesto permite verificar a identidade das cópias sem versionar os binários.
- `procedencia/source_manifest.json`: código da execução, distinto do commit posterior de exportação.
- `procedencia/audit.json`: preflight de dados e partições. Não é a auditoria final dos resultados.
- `generated-traffic/dados/controles_arestas_internas/auditoria.json`: auditoria executada durante cada geração do pacote.

## Recuperar os checkpoints

O acesso ao servidor requer credenciais do laboratório. A partir da raiz do repositório, o comando abaixo copia somente os checkpoints desses controles e não altera arquivos nem processos no servidor:

```sh
rsync -az -e 'ssh -p 2099' \
  --include='/*_cut_k*/' --include='/*_cut_k*/**/' \
  --include='*.pt' --exclude='*' \
  helder@200.128.51.114:/home/helder/controles_20261114/results/completar_controles_20261114/ \
  results/completar_controles_20261114/
```

O exportador exige todos os arquivos do manifesto remoto, confere seus hashes e lê os checkpoints selecionados em CPU para verificar época, MAE de validação e parâmetros finitos. Não executa treinamento nem reavalia o teste. Os `.pt` não são públicos: uma cópia do Git, sem os checkpoints e sem os dados preparados requeridos pelos exportadores existentes, não basta para repetir a exportação completa.

Após recuperar os checkpoints e preparar os dados conforme o README do projeto, usar o ambiente com as dependências do repositório e executar `python -m experiments.export_traffic`. O pacote só é publicado se as verificações passarem e duas gerações independentes coincidirem. As fontes devem estar em um commit; o exportador recusa os novos insumos não versionados, mesmo que `git_worktree_dirty` fosse falso.

Essa conferência estabelece integridade e consistência dos registros. Não demonstra reprodução bit a bit do treinamento em GPU nem, sem reavaliar o teste, que o checkpoint reproduz a métrica registrada. A família complementar contém 14 contrastes, conforme o protocolo; as famílias anteriores permanecem intactas.
