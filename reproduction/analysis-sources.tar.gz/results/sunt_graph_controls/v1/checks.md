# Verificações

1066 verificações; 0 falharam.

| verificação | ok | detalhe |
|---|---|---|
| auditoria results/sunt_centralized_boardings/sunt/seed_007/metrics.json | sim | concluído=600/600, model_edges=None |
| auditoria results/sunt_centralized_boardings/sunt/seed_042/metrics.json | sim | concluído=600/600, model_edges=None |
| auditoria results/sunt_centralized_boardings/sunt/seed_101/metrics.json | sim | concluído=600/600, model_edges=None |
| auditoria results/sunt_centralized_boardings/sunt/seed_123/metrics.json | sim | concluído=600/600, model_edges=None |
| auditoria results/sunt_centralized_boardings/sunt/seed_314/metrics.json | sim | concluído=600/600, model_edges=None |
| auditoria results/sunt_control_noedges/sunt/seed_007/metrics.json | sim | concluído=600/600, model_edges=2903 |
| hash do checkpoint registrado results/sunt_control_noedges/sunt/seed_007/metrics.json | sim |  |
| auditoria results/sunt_control_noedges/sunt/seed_042/metrics.json | sim | concluído=600/600, model_edges=2903 |
| hash do checkpoint registrado results/sunt_control_noedges/sunt/seed_042/metrics.json | sim |  |
| auditoria results/sunt_control_noedges/sunt/seed_101/metrics.json | sim | concluído=600/600, model_edges=2903 |
| hash do checkpoint registrado results/sunt_control_noedges/sunt/seed_101/metrics.json | sim |  |
| auditoria results/sunt_control_noedges/sunt/seed_123/metrics.json | sim | concluído=600/600, model_edges=2903 |
| hash do checkpoint registrado results/sunt_control_noedges/sunt/seed_123/metrics.json | sim |  |
| auditoria results/sunt_control_noedges/sunt/seed_314/metrics.json | sim | concluído=600/600, model_edges=2903 |
| hash do checkpoint registrado results/sunt_control_noedges/sunt/seed_314/metrics.json | sim |  |
| auditoria results/sunt_control_cut20/sunt/seed_007/metrics.json | sim | concluído=600/600, model_edges=8994 |
| hash do checkpoint registrado results/sunt_control_cut20/sunt/seed_007/metrics.json | sim |  |
| auditoria results/sunt_control_cut20/sunt/seed_042/metrics.json | sim | concluído=600/600, model_edges=8994 |
| hash do checkpoint registrado results/sunt_control_cut20/sunt/seed_042/metrics.json | sim |  |
| auditoria results/sunt_control_cut20/sunt/seed_101/metrics.json | sim | concluído=600/600, model_edges=8994 |
| hash do checkpoint registrado results/sunt_control_cut20/sunt/seed_101/metrics.json | sim |  |
| auditoria results/sunt_control_cut20/sunt/seed_123/metrics.json | sim | concluído=600/600, model_edges=8994 |
| hash do checkpoint registrado results/sunt_control_cut20/sunt/seed_123/metrics.json | sim |  |
| auditoria results/sunt_control_cut20/sunt/seed_314/metrics.json | sim | concluído=600/600, model_edges=8994 |
| hash do checkpoint registrado results/sunt_control_cut20/sunt/seed_314/metrics.json | sim |  |
| auditoria results/sunt_fedavg_final/sunt/k020/seed_007/metrics.json | sim | concluído=600/600, model_edges=None |
| auditoria results/sunt_fedavg_final/sunt/k020/seed_042/metrics.json | sim | concluído=600/600, model_edges=None |
| auditoria results/sunt_fedavg_final/sunt/k020/seed_101/metrics.json | sim | concluído=600/600, model_edges=None |
| auditoria results/sunt_fedavg_final/sunt/k020/seed_123/metrics.json | sim | concluído=600/600, model_edges=None |
| auditoria results/sunt_fedavg_final/sunt/k020/seed_314/metrics.json | sim | concluído=600/600, model_edges=None |
| auditoria results/sunt_control_cut166/sunt/seed_007/metrics.json | sim | concluído=600/600, model_edges=7998 |
| hash do checkpoint registrado results/sunt_control_cut166/sunt/seed_007/metrics.json | sim |  |
| auditoria results/sunt_control_cut166/sunt/seed_042/metrics.json | sim | concluído=600/600, model_edges=7998 |
| hash do checkpoint registrado results/sunt_control_cut166/sunt/seed_042/metrics.json | sim |  |
| auditoria results/sunt_control_cut166/sunt/seed_101/metrics.json | sim | concluído=600/600, model_edges=7998 |
| hash do checkpoint registrado results/sunt_control_cut166/sunt/seed_101/metrics.json | sim |  |
| auditoria results/sunt_control_cut166/sunt/seed_123/metrics.json | sim | concluído=600/600, model_edges=7998 |
| hash do checkpoint registrado results/sunt_control_cut166/sunt/seed_123/metrics.json | sim |  |
| auditoria results/sunt_control_cut166/sunt/seed_314/metrics.json | sim | concluído=600/600, model_edges=7998 |
| hash do checkpoint registrado results/sunt_control_cut166/sunt/seed_314/metrics.json | sim |  |
| auditoria results/sunt_fedavg_final/sunt/k166/seed_007/metrics.json | sim | concluído=1000/1000, model_edges=None |
| auditoria results/sunt_fedavg_final/sunt/k166/seed_042/metrics.json | sim | concluído=1000/1000, model_edges=None |
| auditoria results/sunt_fedavg_final/sunt/k166/seed_101/metrics.json | sim | concluído=1000/1000, model_edges=None |
| auditoria results/sunt_fedavg_final/sunt/k166/seed_123/metrics.json | sim | concluído=1000/1000, model_edges=None |
| auditoria results/sunt_fedavg_final/sunt/k166/seed_314/metrics.json | sim | concluído=1000/1000, model_edges=None |
| node_descriptors.csv = o da análise estratificada v1 (estratos e limites fixados) | sim |  |
| test Centralizado s7: 2903 nós, erros finitos ≥ 0 | sim |  |
| test Centralizado s7: mesmos alvos que o Centralizado | sim |  |
| test Centralizado s7: Σerro/Σcount = MAE gravado | sim | 3.947531 |
| test Centralizado s42: 2903 nós, erros finitos ≥ 0 | sim |  |
| test Centralizado s42: mesmos alvos que o Centralizado | sim |  |
| test Centralizado s42: Σerro/Σcount = MAE gravado | sim | 3.950958 |
| test Centralizado s101: 2903 nós, erros finitos ≥ 0 | sim |  |
| test Centralizado s101: mesmos alvos que o Centralizado | sim |  |
| test Centralizado s101: Σerro/Σcount = MAE gravado | sim | 3.935281 |
| test Centralizado s123: 2903 nós, erros finitos ≥ 0 | sim |  |
| test Centralizado s123: mesmos alvos que o Centralizado | sim |  |
| test Centralizado s123: Σerro/Σcount = MAE gravado | sim | 3.937684 |
| test Centralizado s314: 2903 nós, erros finitos ≥ 0 | sim |  |
| test Centralizado s314: mesmos alvos que o Centralizado | sim |  |
| test Centralizado s314: Σerro/Σcount = MAE gravado | sim | 3.936481 |
| test sem_arestas s7: 2903 nós, erros finitos ≥ 0 | sim |  |
| test sem_arestas s7: mesmos alvos que o Centralizado | sim |  |
| test sem_arestas s7: Σerro/Σcount = MAE gravado | sim | 3.967648 |
| test sem_arestas s42: 2903 nós, erros finitos ≥ 0 | sim |  |
| test sem_arestas s42: mesmos alvos que o Centralizado | sim |  |
| test sem_arestas s42: Σerro/Σcount = MAE gravado | sim | 3.985394 |
| test sem_arestas s101: 2903 nós, erros finitos ≥ 0 | sim |  |
| test sem_arestas s101: mesmos alvos que o Centralizado | sim |  |
| test sem_arestas s101: Σerro/Σcount = MAE gravado | sim | 3.970895 |
| test sem_arestas s123: 2903 nós, erros finitos ≥ 0 | sim |  |
| test sem_arestas s123: mesmos alvos que o Centralizado | sim |  |
| test sem_arestas s123: Σerro/Σcount = MAE gravado | sim | 3.938133 |
| test sem_arestas s314: 2903 nós, erros finitos ≥ 0 | sim |  |
| test sem_arestas s314: mesmos alvos que o Centralizado | sim |  |
| test sem_arestas s314: Σerro/Σcount = MAE gravado | sim | 3.952639 |
| test cortes_k20 s7: 2903 nós, erros finitos ≥ 0 | sim |  |
| test cortes_k20 s7: mesmos alvos que o Centralizado | sim |  |
| test cortes_k20 s7: Σerro/Σcount = MAE gravado | sim | 3.931730 |
| test cortes_k20 s42: 2903 nós, erros finitos ≥ 0 | sim |  |
| test cortes_k20 s42: mesmos alvos que o Centralizado | sim |  |
| test cortes_k20 s42: Σerro/Σcount = MAE gravado | sim | 3.990778 |
| test cortes_k20 s101: 2903 nós, erros finitos ≥ 0 | sim |  |
| test cortes_k20 s101: mesmos alvos que o Centralizado | sim |  |
| test cortes_k20 s101: Σerro/Σcount = MAE gravado | sim | 3.953685 |
| test cortes_k20 s123: 2903 nós, erros finitos ≥ 0 | sim |  |
| test cortes_k20 s123: mesmos alvos que o Centralizado | sim |  |
| test cortes_k20 s123: Σerro/Σcount = MAE gravado | sim | 3.928897 |
| test cortes_k20 s314: 2903 nós, erros finitos ≥ 0 | sim |  |
| test cortes_k20 s314: mesmos alvos que o Centralizado | sim |  |
| test cortes_k20 s314: Σerro/Σcount = MAE gravado | sim | 3.929381 |
| test FedAvg_k20 s7: 2903 nós, erros finitos ≥ 0 | sim |  |
| test FedAvg_k20 s7: mesmos alvos que o Centralizado | sim |  |
| test FedAvg_k20 s7: Σerro/Σcount = MAE gravado | sim | 4.087549 |
| test FedAvg_k20 s42: 2903 nós, erros finitos ≥ 0 | sim |  |
| test FedAvg_k20 s42: mesmos alvos que o Centralizado | sim |  |
| test FedAvg_k20 s42: Σerro/Σcount = MAE gravado | sim | 4.030522 |
| test FedAvg_k20 s101: 2903 nós, erros finitos ≥ 0 | sim |  |
| test FedAvg_k20 s101: mesmos alvos que o Centralizado | sim |  |
| test FedAvg_k20 s101: Σerro/Σcount = MAE gravado | sim | 4.090534 |
| test FedAvg_k20 s123: 2903 nós, erros finitos ≥ 0 | sim |  |
| test FedAvg_k20 s123: mesmos alvos que o Centralizado | sim |  |
| test FedAvg_k20 s123: Σerro/Σcount = MAE gravado | sim | 4.032477 |
| test FedAvg_k20 s314: 2903 nós, erros finitos ≥ 0 | sim |  |
| test FedAvg_k20 s314: mesmos alvos que o Centralizado | sim |  |
| test FedAvg_k20 s314: Σerro/Σcount = MAE gravado | sim | 4.128492 |
| test cortes_k166 s7: 2903 nós, erros finitos ≥ 0 | sim |  |
| test cortes_k166 s7: mesmos alvos que o Centralizado | sim |  |
| test cortes_k166 s7: Σerro/Σcount = MAE gravado | sim | 3.936895 |
| test cortes_k166 s42: 2903 nós, erros finitos ≥ 0 | sim |  |
| test cortes_k166 s42: mesmos alvos que o Centralizado | sim |  |
| test cortes_k166 s42: Σerro/Σcount = MAE gravado | sim | 3.942637 |
| test cortes_k166 s101: 2903 nós, erros finitos ≥ 0 | sim |  |
| test cortes_k166 s101: mesmos alvos que o Centralizado | sim |  |
| test cortes_k166 s101: Σerro/Σcount = MAE gravado | sim | 3.908252 |
| test cortes_k166 s123: 2903 nós, erros finitos ≥ 0 | sim |  |
| test cortes_k166 s123: mesmos alvos que o Centralizado | sim |  |
| test cortes_k166 s123: Σerro/Σcount = MAE gravado | sim | 3.925288 |
| test cortes_k166 s314: 2903 nós, erros finitos ≥ 0 | sim |  |
| test cortes_k166 s314: mesmos alvos que o Centralizado | sim |  |
| test cortes_k166 s314: Σerro/Σcount = MAE gravado | sim | 3.941137 |
| test FedAvg_k166 s7: 2903 nós, erros finitos ≥ 0 | sim |  |
| test FedAvg_k166 s7: mesmos alvos que o Centralizado | sim |  |
| test FedAvg_k166 s7: Σerro/Σcount = MAE gravado | sim | 4.337902 |
| test FedAvg_k166 s42: 2903 nós, erros finitos ≥ 0 | sim |  |
| test FedAvg_k166 s42: mesmos alvos que o Centralizado | sim |  |
| test FedAvg_k166 s42: Σerro/Σcount = MAE gravado | sim | 4.329805 |
| test FedAvg_k166 s101: 2903 nós, erros finitos ≥ 0 | sim |  |
| test FedAvg_k166 s101: mesmos alvos que o Centralizado | sim |  |
| test FedAvg_k166 s101: Σerro/Σcount = MAE gravado | sim | 4.353792 |
| test FedAvg_k166 s123: 2903 nós, erros finitos ≥ 0 | sim |  |
| test FedAvg_k166 s123: mesmos alvos que o Centralizado | sim |  |
| test FedAvg_k166 s123: Σerro/Σcount = MAE gravado | sim | 4.317674 |
| test FedAvg_k166 s314: 2903 nós, erros finitos ≥ 0 | sim |  |
| test FedAvg_k166 s314: mesmos alvos que o Centralizado | sim |  |
| test FedAvg_k166 s314: Σerro/Σcount = MAE gravado | sim | 4.337303 |
| validation Centralizado s7: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation Centralizado s7: mesmos alvos que o Centralizado | sim |  |
| validation Centralizado s7: Σerro/Σcount = MAE gravado | sim | 4.871949 |
| validation Centralizado s42: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation Centralizado s42: mesmos alvos que o Centralizado | sim |  |
| validation Centralizado s42: Σerro/Σcount = MAE gravado | sim | 4.991314 |
| validation Centralizado s101: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation Centralizado s101: mesmos alvos que o Centralizado | sim |  |
| validation Centralizado s101: Σerro/Σcount = MAE gravado | sim | 4.901577 |
| validation Centralizado s123: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation Centralizado s123: mesmos alvos que o Centralizado | sim |  |
| validation Centralizado s123: Σerro/Σcount = MAE gravado | sim | 4.886892 |
| validation Centralizado s314: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation Centralizado s314: mesmos alvos que o Centralizado | sim |  |
| validation Centralizado s314: Σerro/Σcount = MAE gravado | sim | 4.934840 |
| validation sem_arestas s7: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation sem_arestas s7: mesmos alvos que o Centralizado | sim |  |
| validation sem_arestas s7: Σerro/Σcount = MAE gravado | sim | 4.934269 |
| validation sem_arestas s42: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation sem_arestas s42: mesmos alvos que o Centralizado | sim |  |
| validation sem_arestas s42: Σerro/Σcount = MAE gravado | sim | 4.975242 |
| validation sem_arestas s101: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation sem_arestas s101: mesmos alvos que o Centralizado | sim |  |
| validation sem_arestas s101: Σerro/Σcount = MAE gravado | sim | 4.914863 |
| validation sem_arestas s123: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation sem_arestas s123: mesmos alvos que o Centralizado | sim |  |
| validation sem_arestas s123: Σerro/Σcount = MAE gravado | sim | 4.938503 |
| validation sem_arestas s314: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation sem_arestas s314: mesmos alvos que o Centralizado | sim |  |
| validation sem_arestas s314: Σerro/Σcount = MAE gravado | sim | 4.868262 |
| validation cortes_k20 s7: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation cortes_k20 s7: mesmos alvos que o Centralizado | sim |  |
| validation cortes_k20 s7: Σerro/Σcount = MAE gravado | sim | 4.916703 |
| validation cortes_k20 s42: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation cortes_k20 s42: mesmos alvos que o Centralizado | sim |  |
| validation cortes_k20 s42: Σerro/Σcount = MAE gravado | sim | 4.944555 |
| validation cortes_k20 s101: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation cortes_k20 s101: mesmos alvos que o Centralizado | sim |  |
| validation cortes_k20 s101: Σerro/Σcount = MAE gravado | sim | 4.971485 |
| validation cortes_k20 s123: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation cortes_k20 s123: mesmos alvos que o Centralizado | sim |  |
| validation cortes_k20 s123: Σerro/Σcount = MAE gravado | sim | 4.919089 |
| validation cortes_k20 s314: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation cortes_k20 s314: mesmos alvos que o Centralizado | sim |  |
| validation cortes_k20 s314: Σerro/Σcount = MAE gravado | sim | 4.801580 |
| validation FedAvg_k20 s7: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation FedAvg_k20 s7: mesmos alvos que o Centralizado | sim |  |
| validation FedAvg_k20 s7: Σerro/Σcount = MAE gravado | sim | 5.163517 |
| validation FedAvg_k20 s42: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation FedAvg_k20 s42: mesmos alvos que o Centralizado | sim |  |
| validation FedAvg_k20 s42: Σerro/Σcount = MAE gravado | sim | 5.131294 |
| validation FedAvg_k20 s101: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation FedAvg_k20 s101: mesmos alvos que o Centralizado | sim |  |
| validation FedAvg_k20 s101: Σerro/Σcount = MAE gravado | sim | 5.116043 |
| validation FedAvg_k20 s123: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation FedAvg_k20 s123: mesmos alvos que o Centralizado | sim |  |
| validation FedAvg_k20 s123: Σerro/Σcount = MAE gravado | sim | 5.096556 |
| validation FedAvg_k20 s314: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation FedAvg_k20 s314: mesmos alvos que o Centralizado | sim |  |
| validation FedAvg_k20 s314: Σerro/Σcount = MAE gravado | sim | 5.073965 |
| validation cortes_k166 s7: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation cortes_k166 s7: mesmos alvos que o Centralizado | sim |  |
| validation cortes_k166 s7: Σerro/Σcount = MAE gravado | sim | 4.869222 |
| validation cortes_k166 s42: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation cortes_k166 s42: mesmos alvos que o Centralizado | sim |  |
| validation cortes_k166 s42: Σerro/Σcount = MAE gravado | sim | 4.912793 |
| validation cortes_k166 s101: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation cortes_k166 s101: mesmos alvos que o Centralizado | sim |  |
| validation cortes_k166 s101: Σerro/Σcount = MAE gravado | sim | 4.877165 |
| validation cortes_k166 s123: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation cortes_k166 s123: mesmos alvos que o Centralizado | sim |  |
| validation cortes_k166 s123: Σerro/Σcount = MAE gravado | sim | 4.913288 |
| validation cortes_k166 s314: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation cortes_k166 s314: mesmos alvos que o Centralizado | sim |  |
| validation cortes_k166 s314: Σerro/Σcount = MAE gravado | sim | 4.881082 |
| validation FedAvg_k166 s7: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation FedAvg_k166 s7: mesmos alvos que o Centralizado | sim |  |
| validation FedAvg_k166 s7: Σerro/Σcount = MAE gravado | sim | 5.319919 |
| validation FedAvg_k166 s42: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation FedAvg_k166 s42: mesmos alvos que o Centralizado | sim |  |
| validation FedAvg_k166 s42: Σerro/Σcount = MAE gravado | sim | 5.349717 |
| validation FedAvg_k166 s101: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation FedAvg_k166 s101: mesmos alvos que o Centralizado | sim |  |
| validation FedAvg_k166 s101: Σerro/Σcount = MAE gravado | sim | 5.295494 |
| validation FedAvg_k166 s123: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation FedAvg_k166 s123: mesmos alvos que o Centralizado | sim |  |
| validation FedAvg_k166 s123: Σerro/Σcount = MAE gravado | sim | 5.424843 |
| validation FedAvg_k166 s314: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation FedAvg_k166 s314: mesmos alvos que o Centralizado | sim |  |
| validation FedAvg_k166 s314: Σerro/Σcount = MAE gravado | sim | 5.311405 |

Verificações por estrato completas em `checks.json`.
