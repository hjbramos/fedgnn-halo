# Registro de máquinas, sessões e logs — controles de grafo do SUNT (v1)

## Código

- Branch `controles-grafo-sunt`, commit `590a16c` (código, configs e protocolo; nenhum resultado
  commitado). A `main` não foi alterada. Mesmo commit no Terumo durante smokes e campanha.
- Análise posterior (local): `experiments/sunt_graph_controls_analysis.py`.

## Máquinas verificadas em 05/10/2026 (~17:05)

| máquina | estado antes do lançamento | uso |
|---|---|---|
| Terumo (`terumo`, 60 CPUs, 125 GB) | GPU 0 L40S 46 GB e GPUs 1–4 A16 15 GB, todas com 0 MiB e 0 %; carga média ~16–20 de outros usuários (processos Ray de outro usuário); 92 GB livres; nenhuma sessão `tmux` minha | smokes e campanha |
| desktop (`desktop-remote` via Tailscale; `desktop` na LAN não respondeu) | RTX 2060 ociosa, 27 GB livres, nenhuma sessão `tmux`; repositório em `~/Developer/research/fed-stgnn-traffic`, commit `329fdd4` | não usado (Terumo livre) |

Dados: hashes de série, máscara, origens, nós, adjacência e scaler idênticos entre o notebook local e o
Terumo (`prelaunch_*.json`). O arquivo `sunt_n_boardings.parquet` local difere do Terumo e do desktop,
mas os tensores carregados por `load_experiment` são idênticos.

## Verificações (sem treino)

| onde | sessão / comando | log | resultado |
|---|---|---|---|
| local | `python -m experiments.sunt_graph_controls_check` | `prelaunch_MacBook-Pro-de-Helder.json` | 42/42 |
| Terumo | tmux `ctrl_check`, CPU | `~/fed-stgnn-traffic/logs/sunt_graph_controls/prelaunch_terumo.log` | 42/42 |
| Terumo | tmux `ctrl_smoke` (fim), `--smoke`, CPU | `.../prelaunch_terumo_smoke.log` | 50/50 |

## Smokes (não são resultado)

tmux `ctrl_smoke`, Terumo GPU 1 (A16), semente 7, 1 época e depois `--max-epochs 2` no mesmo diretório
(retomou da época 1 pelo `last.pt` nos dois braços), saída `results/_smoke/sunt_control_{noedges,cut20}`,
sem teste. Logs `logs/sunt_graph_controls/smoke_{noedges,cut20}_ep{1,2}.log`. Pico de memória ~2,5 GB por
processo; ~18 s por época sozinho numa A16.

## Campanha (treino cego, 600 épocas, sem teste)

Lançada em 05/10/2026 17:18 (horário do Terumo). Um `tmux` por semente, duas janelas (`noedges`,
`cut20`) na mesma GPU:

| semente | sessão tmux | GPU (Terumo) | GPU da referência (Centralizado) | logs |
|---|---|---|---|---|
| 7 | `ctrl_s7` | 0 — L40S | L40S | `logs/sunt_graph_controls/train_{noedges,cut20}_s7.log` |
| 42 | `ctrl_s42` | 1 — A16 | A16 | `..._s42.log` |
| 101 | `ctrl_s101` | 2 — A16 | A16 | `..._s101.log` |
| 123 | `ctrl_s123` | 3 — A16 | A16 | `..._s123.log` |
| 314 | `ctrl_s314` | 4 — A16 | A16 | `..._s314.log` |

Comando por janela: `CUDA_VISIBLE_DEVICES=<g> python -m experiments.run_grid --config
config/sunt_control_<braço>_probe.yaml --backend local --seeds <s>`. Saída
`results/sunt_control_{noedges,cut20}_probe/sunt/seed_XXX/` (com `last.pt` para retomada).

Avaliação final (depois das cinco sementes de cada braço):

```bash
python -m experiments.evaluate_frozen --probe results/sunt_control_noedges_probe --config config/sunt_control_noedges.yaml
python -m experiments.evaluate_frozen --probe results/sunt_control_cut20_probe --config config/sunt_control_cut20.yaml
```

## Ampliação: cortes_k166 no desktop (`protocol_k166.md`)

Código: mesma branch, commit `b0a32f2` (configs `sunt_control_cut166*`, verificação estendida a k=166,
`scripts/thermal_guard.sh`). O Terumo continua em `590a16c` (só arquivos novos e o script de verificação
mudaram; os treinos em curso não são afetados).

Desktop `helder-desktop` (`ssh desktop-remote`), relógio em UTC−4 (o Terumo registra UTC−3).
Repositório `~/Developer/research/fed-stgnn-traffic`, env `~/miniconda3/envs/fedstgnn_env` (torch
2.5.1+cu124, PyG 2.4.0, numpy 1.23.0, pandas 1.3.5).

Condição do hardware (05/10, antes do lançamento): RTX 2060 6 GB ociosa a 42 °C (lentidão 90 °C,
desligamento 93 °C), i9-9900K a 41 °C (alto 86 °C, crítico 100 °C), 27 GB de RAM livres, swap sem uso,
126 GB livres em disco. Nenhum erro de GPU (Xid), OOM ou travamento nos boots do journal; os únicos
eventos extras são do Bluetooth. Campanha anterior no desktop (04–05/10, ~12,7 h a carga ~15/16,
`~/vigias/sunt-loading-fedgnnhet.log`) terminou sem relançamentos.

| etapa | sessão tmux | log (em `logs/sunt_graph_controls/`) | resultado |
|---|---|---|---|
| verificação (CPU) | `ctrl_check` | `prelaunch_desktop.log`, `results/sunt_graph_controls/v1/prelaunch_helder-desktop.json` | 57/57; dados idênticos ao Terumo |
| smoke + retomada (s7, 1 → 2 épocas) | `ctrl_smoke` | `smoke_cut166_ep{1,2}.log` | retomou da época 1 |
| teste de carga (s42, s101, s123 simultâneas, 10 épocas) | `ctrl_smoke` | `smoke_cut166_load_s*.log`, `thermal_desktop_smoke.log` | 1 230 MiB de GPU e ~2,3 GB de RAM por processo; 4,1 de 6 GB de GPU em uso; ~17 s/época; GPU estabilizou em ~60 °C, CPU em ~73 °C |
| verificação dos smokes (CPU) | `ctrl_smoke` | `prelaunch_desktop_smoke.log` | 73/73 |

Concorrência: **3 execuções simultâneas** (5 exigiriam ~6,6 GB de GPU, acima dos 6 GB; 4 deixariam
margem pequena com a tela usando ~0,4 GB). Fila: janela `a` s7 → s123, `b` s42 → s314, `c` s101.

Campanha lançada em 05/10/2026 16:36 (UTC−4), tmux `ctrl166`: janela `guard` com
`scripts/thermal_guard.sh` (pausa os treinos se a GPU passar de 85 °C ou a CPU de 90 °C em duas leituras
seguidas; log `thermal_desktop_cut166.log`), janelas `a`, `b`, `c` com
`python -m experiments.run_grid --config config/sunt_control_cut166_probe.yaml --backend local --seeds <s>`,
logs `train_cut166_s<s>.log`, saída `results/sunt_control_cut166_probe/sunt/seed_XXX/`.
Hardware frente às referências: Centralizado e FedAvg k=166 rodaram no Terumo (s7 L40S, demais A16);
este braço roda inteiro na RTX 2060.

## Término no Terumo

As 10 execuções concluíram as 600 épocas sem falha nem retomada (167–192 min cada; tempos não
comparáveis entre máquinas). Melhores épocas: sem_arestas 598/542/588/566/537, cortes_k20
577/408/404/582/542 (s7/s42/s101/s123/s314). Nenhum `metrics.json` de treino tinha teste.

Avaliação congelada em 05/10 20:31 (UTC−3), tmux `ctrl_eval`, GPU 0 (L40S):
`evaluate_frozen` para os dois braços (validação recalculada reproduziu a gravada em todas as sementes),
logs `eval_{noedges,cut20}.log`; hashes dos `best_model.pt` em `checkpoints_sha256_terumo.csv`. Copiados
para o notebook só `metrics.json`, `history.csv`, sumários e logs (`logs_terumo/`); os checkpoints ficam no
Terumo.

## Término no desktop

As 5 execuções do cortes_k166 concluíram as 600 épocas sem falha nem retomada (fila: s7, s42, s101 e
depois s123, s314). Melhores épocas 577/537/563/599/549. Temperatura máxima registrada pelo vigia:
GPU 63 °C, CPU 81 °C; nenhuma pausa. Avaliação congelada em 05/10 ~21:45 (UTC−4), tmux `ctrl166_eval`,
RTX 2060, `eval_cut166.log` (validação reproduzida); hashes em `checkpoints_sha256_desktop.csv`. Sessões
`ctrl166`, `ctrl_smoke` e `ctrl166_eval` encerradas. Logs copiados para `logs_desktop/`.

Análise local: `python -m experiments.sunt_graph_controls_analysis`, 1 066 verificações, 0 falhas;
relatório em `report.md`.

## Ocorrências

Nenhuma no Terumo nem no desktop.
