# PRÉVIA DE LAYOUT — DADOS SUBSTITUTOS, NÃO SÃO RESULTADOS

Gerado por `python -m experiments.sunt_graph_controls_analysis --layout-preview`. Os braços sem_arestas, cortes_k20 e cortes_k166 foram substituídos por execuções existentes de outros métodos:

- sem_arestas: `results/sunt_fedprox_final/sunt/k020/mu0p01/seed_{seed:03d}/metrics.json`
- cortes_k20: `results/sunt_ditto_final/sunt/k020/lam_per_client/seed_{seed:03d}/metrics.json`
- cortes_k166: `results/sunt_fedgnnhet_final/sunt/k166/halo_1hop/seed_{seed:03d}/metrics.json`

Serve só para conferir código, tabelas e figuras antes dos resultados reais. Nada aqui deve ser lido, citado ou comparado como resultado.
