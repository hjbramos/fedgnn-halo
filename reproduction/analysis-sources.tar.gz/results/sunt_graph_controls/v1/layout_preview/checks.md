# Verificações

1066 verificações; 0 falharam.

| verificação | ok | detalhe |
|---|---|---|
| auditoria results/sunt_centralized_boardings/sunt/seed_007/metrics.json | sim | concluído=600/600, model_edges=None |
| auditoria results/sunt_centralized_boardings/sunt/seed_042/metrics.json | sim | concluído=600/600, model_edges=None |
| auditoria results/sunt_centralized_boardings/sunt/seed_101/metrics.json | sim | concluído=600/600, model_edges=None |
| auditoria results/sunt_centralized_boardings/sunt/seed_123/metrics.json | sim | concluído=600/600, model_edges=None |
| auditoria results/sunt_centralized_boardings/sunt/seed_314/metrics.json | sim | concluído=600/600, model_edges=None |
| auditoria results/sunt_fedprox_final/sunt/k020/mu0p01/seed_007/metrics.json | sim | [prévia: substituto, auditoria não se aplica] concluído=None/600, model_edges=None |
| hash do checkpoint registrado results/sunt_fedprox_final/sunt/k020/mu0p01/seed_007/metrics.json | sim | [prévia: substituto, auditoria não se aplica]  |
| auditoria results/sunt_fedprox_final/sunt/k020/mu0p01/seed_042/metrics.json | sim | [prévia: substituto, auditoria não se aplica] concluído=None/600, model_edges=None |
| hash do checkpoint registrado results/sunt_fedprox_final/sunt/k020/mu0p01/seed_042/metrics.json | sim | [prévia: substituto, auditoria não se aplica]  |
| auditoria results/sunt_fedprox_final/sunt/k020/mu0p01/seed_101/metrics.json | sim | [prévia: substituto, auditoria não se aplica] concluído=None/600, model_edges=None |
| hash do checkpoint registrado results/sunt_fedprox_final/sunt/k020/mu0p01/seed_101/metrics.json | sim | [prévia: substituto, auditoria não se aplica]  |
| auditoria results/sunt_fedprox_final/sunt/k020/mu0p01/seed_123/metrics.json | sim | [prévia: substituto, auditoria não se aplica] concluído=None/600, model_edges=None |
| hash do checkpoint registrado results/sunt_fedprox_final/sunt/k020/mu0p01/seed_123/metrics.json | sim | [prévia: substituto, auditoria não se aplica]  |
| auditoria results/sunt_fedprox_final/sunt/k020/mu0p01/seed_314/metrics.json | sim | [prévia: substituto, auditoria não se aplica] concluído=None/600, model_edges=None |
| hash do checkpoint registrado results/sunt_fedprox_final/sunt/k020/mu0p01/seed_314/metrics.json | sim | [prévia: substituto, auditoria não se aplica]  |
| auditoria results/sunt_ditto_final/sunt/k020/lam_per_client/seed_007/metrics.json | sim | [prévia: substituto, auditoria não se aplica] concluído=None/600, model_edges=None |
| hash do checkpoint registrado results/sunt_ditto_final/sunt/k020/lam_per_client/seed_007/metrics.json | sim | [prévia: substituto, auditoria não se aplica]  |
| auditoria results/sunt_ditto_final/sunt/k020/lam_per_client/seed_042/metrics.json | sim | [prévia: substituto, auditoria não se aplica] concluído=None/600, model_edges=None |
| hash do checkpoint registrado results/sunt_ditto_final/sunt/k020/lam_per_client/seed_042/metrics.json | sim | [prévia: substituto, auditoria não se aplica]  |
| auditoria results/sunt_ditto_final/sunt/k020/lam_per_client/seed_101/metrics.json | sim | [prévia: substituto, auditoria não se aplica] concluído=None/600, model_edges=None |
| hash do checkpoint registrado results/sunt_ditto_final/sunt/k020/lam_per_client/seed_101/metrics.json | sim | [prévia: substituto, auditoria não se aplica]  |
| auditoria results/sunt_ditto_final/sunt/k020/lam_per_client/seed_123/metrics.json | sim | [prévia: substituto, auditoria não se aplica] concluído=None/600, model_edges=None |
| hash do checkpoint registrado results/sunt_ditto_final/sunt/k020/lam_per_client/seed_123/metrics.json | sim | [prévia: substituto, auditoria não se aplica]  |
| auditoria results/sunt_ditto_final/sunt/k020/lam_per_client/seed_314/metrics.json | sim | [prévia: substituto, auditoria não se aplica] concluído=None/600, model_edges=None |
| hash do checkpoint registrado results/sunt_ditto_final/sunt/k020/lam_per_client/seed_314/metrics.json | sim | [prévia: substituto, auditoria não se aplica]  |
| auditoria results/sunt_fedavg_final/sunt/k020/seed_007/metrics.json | sim | concluído=600/600, model_edges=None |
| auditoria results/sunt_fedavg_final/sunt/k020/seed_042/metrics.json | sim | concluído=600/600, model_edges=None |
| auditoria results/sunt_fedavg_final/sunt/k020/seed_101/metrics.json | sim | concluído=600/600, model_edges=None |
| auditoria results/sunt_fedavg_final/sunt/k020/seed_123/metrics.json | sim | concluído=600/600, model_edges=None |
| auditoria results/sunt_fedavg_final/sunt/k020/seed_314/metrics.json | sim | concluído=600/600, model_edges=None |
| auditoria results/sunt_fedgnnhet_final/sunt/k166/halo_1hop/seed_007/metrics.json | sim | [prévia: substituto, auditoria não se aplica] concluído=None/600, model_edges=None |
| hash do checkpoint registrado results/sunt_fedgnnhet_final/sunt/k166/halo_1hop/seed_007/metrics.json | sim | [prévia: substituto, auditoria não se aplica]  |
| auditoria results/sunt_fedgnnhet_final/sunt/k166/halo_1hop/seed_042/metrics.json | sim | [prévia: substituto, auditoria não se aplica] concluído=None/600, model_edges=None |
| hash do checkpoint registrado results/sunt_fedgnnhet_final/sunt/k166/halo_1hop/seed_042/metrics.json | sim | [prévia: substituto, auditoria não se aplica]  |
| auditoria results/sunt_fedgnnhet_final/sunt/k166/halo_1hop/seed_101/metrics.json | sim | [prévia: substituto, auditoria não se aplica] concluído=None/600, model_edges=None |
| hash do checkpoint registrado results/sunt_fedgnnhet_final/sunt/k166/halo_1hop/seed_101/metrics.json | sim | [prévia: substituto, auditoria não se aplica]  |
| auditoria results/sunt_fedgnnhet_final/sunt/k166/halo_1hop/seed_123/metrics.json | sim | [prévia: substituto, auditoria não se aplica] concluído=None/600, model_edges=None |
| hash do checkpoint registrado results/sunt_fedgnnhet_final/sunt/k166/halo_1hop/seed_123/metrics.json | sim | [prévia: substituto, auditoria não se aplica]  |
| auditoria results/sunt_fedgnnhet_final/sunt/k166/halo_1hop/seed_314/metrics.json | sim | [prévia: substituto, auditoria não se aplica] concluído=None/600, model_edges=None |
| hash do checkpoint registrado results/sunt_fedgnnhet_final/sunt/k166/halo_1hop/seed_314/metrics.json | sim | [prévia: substituto, auditoria não se aplica]  |
| auditoria results/sunt_fedavg_final/sunt/k166/seed_007/metrics.json | sim | concluído=1000/1000, model_edges=None |
| auditoria results/sunt_fedavg_final/sunt/k166/seed_042/metrics.json | sim | concluído=1000/1000, model_edges=None |
| auditoria results/sunt_fedavg_final/sunt/k166/seed_101/metrics.json | sim | concluído=1000/1000, model_edges=None |
| auditoria results/sunt_fedavg_final/sunt/k166/seed_123/metrics.json | sim | concluído=1000/1000, model_edges=None |
| auditoria results/sunt_fedavg_final/sunt/k166/seed_314/metrics.json | sim | concluído=1000/1000, model_edges=None |
| node_descriptors.csv = o da análise estratificada v1 (estratos e limites fixados) | sim |  |
| test Centralizado s7: 2903 nós, erros finitos ≥ 0 | sim |  |
| test Centralizado s7: mesmos alvos que o Centralizado | sim |  |
| test Centralizado s7: Σerro/Σcount = MAE gravado | sim | 3.947531 |
| test Centralizado s42: 2903 nós, erros finitos ≥ 0 | sim |  |
| test Centralizado s42: mesmos alvos que o Centralizado | sim |  |
| test Centralizado s42: Σerro/Σcount = MAE gravado | sim | 3.950958 |
| test Centralizado s101: 2903 nós, erros finitos ≥ 0 | sim |  |
| test Centralizado s101: mesmos alvos que o Centralizado | sim |  |
| test Centralizado s101: Σerro/Σcount = MAE gravado | sim | 3.935281 |
| test Centralizado s123: 2903 nós, erros finitos ≥ 0 | sim |  |
| test Centralizado s123: mesmos alvos que o Centralizado | sim |  |
| test Centralizado s123: Σerro/Σcount = MAE gravado | sim | 3.937684 |
| test Centralizado s314: 2903 nós, erros finitos ≥ 0 | sim |  |
| test Centralizado s314: mesmos alvos que o Centralizado | sim |  |
| test Centralizado s314: Σerro/Σcount = MAE gravado | sim | 3.936481 |
| test sem_arestas s7: 2903 nós, erros finitos ≥ 0 | sim |  |
| test sem_arestas s7: mesmos alvos que o Centralizado | sim |  |
| test sem_arestas s7: Σerro/Σcount = MAE gravado | sim | 4.075134 |
| test sem_arestas s42: 2903 nós, erros finitos ≥ 0 | sim |  |
| test sem_arestas s42: mesmos alvos que o Centralizado | sim |  |
| test sem_arestas s42: Σerro/Σcount = MAE gravado | sim | 4.048693 |
| test sem_arestas s101: 2903 nós, erros finitos ≥ 0 | sim |  |
| test sem_arestas s101: mesmos alvos que o Centralizado | sim |  |
| test sem_arestas s101: Σerro/Σcount = MAE gravado | sim | 4.062157 |
| test sem_arestas s123: 2903 nós, erros finitos ≥ 0 | sim |  |
| test sem_arestas s123: mesmos alvos que o Centralizado | sim |  |
| test sem_arestas s123: Σerro/Σcount = MAE gravado | sim | 4.054926 |
| test sem_arestas s314: 2903 nós, erros finitos ≥ 0 | sim |  |
| test sem_arestas s314: mesmos alvos que o Centralizado | sim |  |
| test sem_arestas s314: Σerro/Σcount = MAE gravado | sim | 4.039675 |
| test cortes_k20 s7: 2903 nós, erros finitos ≥ 0 | sim |  |
| test cortes_k20 s7: mesmos alvos que o Centralizado | sim |  |
| test cortes_k20 s7: Σerro/Σcount = MAE gravado | sim | 4.052559 |
| test cortes_k20 s42: 2903 nós, erros finitos ≥ 0 | sim |  |
| test cortes_k20 s42: mesmos alvos que o Centralizado | sim |  |
| test cortes_k20 s42: Σerro/Σcount = MAE gravado | sim | 4.074608 |
| test cortes_k20 s101: 2903 nós, erros finitos ≥ 0 | sim |  |
| test cortes_k20 s101: mesmos alvos que o Centralizado | sim |  |
| test cortes_k20 s101: Σerro/Σcount = MAE gravado | sim | 4.108630 |
| test cortes_k20 s123: 2903 nós, erros finitos ≥ 0 | sim |  |
| test cortes_k20 s123: mesmos alvos que o Centralizado | sim |  |
| test cortes_k20 s123: Σerro/Σcount = MAE gravado | sim | 4.041145 |
| test cortes_k20 s314: 2903 nós, erros finitos ≥ 0 | sim |  |
| test cortes_k20 s314: mesmos alvos que o Centralizado | sim |  |
| test cortes_k20 s314: Σerro/Σcount = MAE gravado | sim | 4.048158 |
| test FedAvg_k20 s7: 2903 nós, erros finitos ≥ 0 | sim |  |
| test FedAvg_k20 s7: mesmos alvos que o Centralizado | sim |  |
| test FedAvg_k20 s7: Σerro/Σcount = MAE gravado | sim | 4.087549 |
| test FedAvg_k20 s42: 2903 nós, erros finitos ≥ 0 | sim |  |
| test FedAvg_k20 s42: mesmos alvos que o Centralizado | sim |  |
| test FedAvg_k20 s42: Σerro/Σcount = MAE gravado | sim | 4.030522 |
| test FedAvg_k20 s101: 2903 nós, erros finitos ≥ 0 | sim |  |
| test FedAvg_k20 s101: mesmos alvos que o Centralizado | sim |  |
| test FedAvg_k20 s101: Σerro/Σcount = MAE gravado | sim | 4.090534 |
| test FedAvg_k20 s123: 2903 nós, erros finitos ≥ 0 | sim |  |
| test FedAvg_k20 s123: mesmos alvos que o Centralizado | sim |  |
| test FedAvg_k20 s123: Σerro/Σcount = MAE gravado | sim | 4.032477 |
| test FedAvg_k20 s314: 2903 nós, erros finitos ≥ 0 | sim |  |
| test FedAvg_k20 s314: mesmos alvos que o Centralizado | sim |  |
| test FedAvg_k20 s314: Σerro/Σcount = MAE gravado | sim | 4.128492 |
| test cortes_k166 s7: 2903 nós, erros finitos ≥ 0 | sim |  |
| test cortes_k166 s7: mesmos alvos que o Centralizado | sim |  |
| test cortes_k166 s7: Σerro/Σcount = MAE gravado | sim | 4.291702 |
| test cortes_k166 s42: 2903 nós, erros finitos ≥ 0 | sim |  |
| test cortes_k166 s42: mesmos alvos que o Centralizado | sim |  |
| test cortes_k166 s42: Σerro/Σcount = MAE gravado | sim | 4.365206 |
| test cortes_k166 s101: 2903 nós, erros finitos ≥ 0 | sim |  |
| test cortes_k166 s101: mesmos alvos que o Centralizado | sim |  |
| test cortes_k166 s101: Σerro/Σcount = MAE gravado | sim | 4.332825 |
| test cortes_k166 s123: 2903 nós, erros finitos ≥ 0 | sim |  |
| test cortes_k166 s123: mesmos alvos que o Centralizado | sim |  |
| test cortes_k166 s123: Σerro/Σcount = MAE gravado | sim | 4.330858 |
| test cortes_k166 s314: 2903 nós, erros finitos ≥ 0 | sim |  |
| test cortes_k166 s314: mesmos alvos que o Centralizado | sim |  |
| test cortes_k166 s314: Σerro/Σcount = MAE gravado | sim | 4.323319 |
| test FedAvg_k166 s7: 2903 nós, erros finitos ≥ 0 | sim |  |
| test FedAvg_k166 s7: mesmos alvos que o Centralizado | sim |  |
| test FedAvg_k166 s7: Σerro/Σcount = MAE gravado | sim | 4.337902 |
| test FedAvg_k166 s42: 2903 nós, erros finitos ≥ 0 | sim |  |
| test FedAvg_k166 s42: mesmos alvos que o Centralizado | sim |  |
| test FedAvg_k166 s42: Σerro/Σcount = MAE gravado | sim | 4.329805 |
| test FedAvg_k166 s101: 2903 nós, erros finitos ≥ 0 | sim |  |
| test FedAvg_k166 s101: mesmos alvos que o Centralizado | sim |  |
| test FedAvg_k166 s101: Σerro/Σcount = MAE gravado | sim | 4.353792 |
| test FedAvg_k166 s123: 2903 nós, erros finitos ≥ 0 | sim |  |
| test FedAvg_k166 s123: mesmos alvos que o Centralizado | sim |  |
| test FedAvg_k166 s123: Σerro/Σcount = MAE gravado | sim | 4.317674 |
| test FedAvg_k166 s314: 2903 nós, erros finitos ≥ 0 | sim |  |
| test FedAvg_k166 s314: mesmos alvos que o Centralizado | sim |  |
| test FedAvg_k166 s314: Σerro/Σcount = MAE gravado | sim | 4.337303 |
| validation Centralizado s7: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation Centralizado s7: mesmos alvos que o Centralizado | sim |  |
| validation Centralizado s7: Σerro/Σcount = MAE gravado | sim | 4.871949 |
| validation Centralizado s42: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation Centralizado s42: mesmos alvos que o Centralizado | sim |  |
| validation Centralizado s42: Σerro/Σcount = MAE gravado | sim | 4.991314 |
| validation Centralizado s101: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation Centralizado s101: mesmos alvos que o Centralizado | sim |  |
| validation Centralizado s101: Σerro/Σcount = MAE gravado | sim | 4.901577 |
| validation Centralizado s123: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation Centralizado s123: mesmos alvos que o Centralizado | sim |  |
| validation Centralizado s123: Σerro/Σcount = MAE gravado | sim | 4.886892 |
| validation Centralizado s314: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation Centralizado s314: mesmos alvos que o Centralizado | sim |  |
| validation Centralizado s314: Σerro/Σcount = MAE gravado | sim | 4.934840 |
| validation sem_arestas s7: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation sem_arestas s7: mesmos alvos que o Centralizado | sim |  |
| validation sem_arestas s7: Σerro/Σcount = MAE gravado | sim | 5.105262 |
| validation sem_arestas s42: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation sem_arestas s42: mesmos alvos que o Centralizado | sim |  |
| validation sem_arestas s42: Σerro/Σcount = MAE gravado | sim | 5.100136 |
| validation sem_arestas s101: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation sem_arestas s101: mesmos alvos que o Centralizado | sim |  |
| validation sem_arestas s101: Σerro/Σcount = MAE gravado | sim | 5.112045 |
| validation sem_arestas s123: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation sem_arestas s123: mesmos alvos que o Centralizado | sim |  |
| validation sem_arestas s123: Σerro/Σcount = MAE gravado | sim | 5.079308 |
| validation sem_arestas s314: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation sem_arestas s314: mesmos alvos que o Centralizado | sim |  |
| validation sem_arestas s314: Σerro/Σcount = MAE gravado | sim | 5.107387 |
| validation cortes_k20 s7: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation cortes_k20 s7: mesmos alvos que o Centralizado | sim |  |
| validation cortes_k20 s7: Σerro/Σcount = MAE gravado | sim | 5.069315 |
| validation cortes_k20 s42: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation cortes_k20 s42: mesmos alvos que o Centralizado | sim |  |
| validation cortes_k20 s42: Σerro/Σcount = MAE gravado | sim | 5.011761 |
| validation cortes_k20 s101: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation cortes_k20 s101: mesmos alvos que o Centralizado | sim |  |
| validation cortes_k20 s101: Σerro/Σcount = MAE gravado | sim | 5.167740 |
| validation cortes_k20 s123: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation cortes_k20 s123: mesmos alvos que o Centralizado | sim |  |
| validation cortes_k20 s123: Σerro/Σcount = MAE gravado | sim | 5.035257 |
| validation cortes_k20 s314: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation cortes_k20 s314: mesmos alvos que o Centralizado | sim |  |
| validation cortes_k20 s314: Σerro/Σcount = MAE gravado | sim | 5.002567 |
| validation FedAvg_k20 s7: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation FedAvg_k20 s7: mesmos alvos que o Centralizado | sim |  |
| validation FedAvg_k20 s7: Σerro/Σcount = MAE gravado | sim | 5.163517 |
| validation FedAvg_k20 s42: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation FedAvg_k20 s42: mesmos alvos que o Centralizado | sim |  |
| validation FedAvg_k20 s42: Σerro/Σcount = MAE gravado | sim | 5.131294 |
| validation FedAvg_k20 s101: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation FedAvg_k20 s101: mesmos alvos que o Centralizado | sim |  |
| validation FedAvg_k20 s101: Σerro/Σcount = MAE gravado | sim | 5.116043 |
| validation FedAvg_k20 s123: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation FedAvg_k20 s123: mesmos alvos que o Centralizado | sim |  |
| validation FedAvg_k20 s123: Σerro/Σcount = MAE gravado | sim | 5.096556 |
| validation FedAvg_k20 s314: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation FedAvg_k20 s314: mesmos alvos que o Centralizado | sim |  |
| validation FedAvg_k20 s314: Σerro/Σcount = MAE gravado | sim | 5.073965 |
| validation cortes_k166 s7: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation cortes_k166 s7: mesmos alvos que o Centralizado | sim |  |
| validation cortes_k166 s7: Σerro/Σcount = MAE gravado | sim | 5.213458 |
| validation cortes_k166 s42: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation cortes_k166 s42: mesmos alvos que o Centralizado | sim |  |
| validation cortes_k166 s42: Σerro/Σcount = MAE gravado | sim | 5.305940 |
| validation cortes_k166 s101: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation cortes_k166 s101: mesmos alvos que o Centralizado | sim |  |
| validation cortes_k166 s101: Σerro/Σcount = MAE gravado | sim | 5.274762 |
| validation cortes_k166 s123: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation cortes_k166 s123: mesmos alvos que o Centralizado | sim |  |
| validation cortes_k166 s123: Σerro/Σcount = MAE gravado | sim | 5.435608 |
| validation cortes_k166 s314: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation cortes_k166 s314: mesmos alvos que o Centralizado | sim |  |
| validation cortes_k166 s314: Σerro/Σcount = MAE gravado | sim | 5.285087 |
| validation FedAvg_k166 s7: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation FedAvg_k166 s7: mesmos alvos que o Centralizado | sim |  |
| validation FedAvg_k166 s7: Σerro/Σcount = MAE gravado | sim | 5.319919 |
| validation FedAvg_k166 s42: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation FedAvg_k166 s42: mesmos alvos que o Centralizado | sim |  |
| validation FedAvg_k166 s42: Σerro/Σcount = MAE gravado | sim | 5.349717 |
| validation FedAvg_k166 s101: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation FedAvg_k166 s101: mesmos alvos que o Centralizado | sim |  |
| validation FedAvg_k166 s101: Σerro/Σcount = MAE gravado | sim | 5.295494 |
| validation FedAvg_k166 s123: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation FedAvg_k166 s123: mesmos alvos que o Centralizado | sim |  |
| validation FedAvg_k166 s123: Σerro/Σcount = MAE gravado | sim | 5.424843 |
| validation FedAvg_k166 s314: 2903 nós, erros finitos ≥ 0 | sim |  |
| validation FedAvg_k166 s314: mesmos alvos que o Centralizado | sim |  |
| validation FedAvg_k166 s314: Σerro/Σcount = MAE gravado | sim | 5.311405 |

Verificações por estrato completas em `checks.json`.
