# SUNT — controles centralizados de grafo (v1): valor do grafo e das arestas cortadas

**Natureza:** controles pré-especificados em [`protocol.md`](protocol.md) e, para k=166,
[`protocol_k166.md`](protocol_k166.md), ambos fixados antes de qualquer smoke ou treino e antes de
qualquer resultado de teste dos controles (os hashes são conferidos pelo script). Leitura exploratória:
5 sementes, IC95% `t` pareado sem ajuste para multiplicidade, semente como réplica. Δ em embarques/h
(MAE de teste ponderado por alvos observados); negativo favorece o primeiro braço.

Reprodução (local, sem treino):

```bash
python -m experiments.sunt_graph_controls_analysis
```

Tabelas completas em [`summary_tables.md`](summary_tables.md); dados em `contrasts.csv`,
`boundary_vs_interior.csv`, `strata_metrics.csv`; auditoria em `audit_runs.csv`, `checks.md` e
`manifest.json`; máquinas, sessões e logs em [`runs.md`](runs.md). A pasta `layout_preview/` contém só
testes de layout com dados substitutos e **não é resultado**.

## Execuções e verificações

| braço | execuções | máquina / GPU | épocas | melhores épocas (s7/s42/s101/s123/s314) |
|---|---|---|---|---|
| sem_arestas | 5 | Terumo: s7 L40S, demais A16 | 600 | 598 / 542 / 588 / 566 / 537 |
| cortes_k20 | 5 | Terumo: s7 L40S, demais A16 | 600 | 577 / 408 / 404 / 582 / 542 |
| cortes_k166 | 5 | desktop: RTX 2060 | 600 | 577 / 537 / 563 / 599 / 549 |
| Centralizado completo (referência) | 5 | Terumo: s7 L40S, demais A16 | 600 | existentes |
| FedAvg k=20 e k=166 (referência) | 5 + 5 | Terumo | 600 / 1 000 rodadas | existentes |

- Cinco sementes completas em todos os braços; nenhuma falha, retomada ou execução incompleta. Treino
  cego (sem teste); teste avaliado depois por `evaluate_frozen`, que exigiu reproduzir a validação gravada.
- Antes do treino: 42/42 (notebook), 42/42 e 50/50 (Terumo), 57/57 e 73/73 (desktop). Dados idênticos nas
  três máquinas. Com os mesmos parâmetros e entradas, os controles com cortes reproduzem a reunião dos
  modelos-cliente do FedAvg (diferença máxima 0 em k=20 e 2,4e-7 em k=166); nada se propaga entre
  clientes nem, no sem_arestas, entre nós.
- Análise: 1 066 verificações, 0 falhas (configuração e arestas efetivas registradas em cada `metrics.json`,
  hashes dos checkpoints em `checkpoints_sha256.csv`, mesmos alvos em todos os braços, recomposição dos
  estratos igual ao MAE global).
- Desktop: GPU no máximo 63 °C e CPU 81 °C durante a campanha; o vigia térmico não precisou pausar.

## Resultados observados (teste)

### MAE global

| braço | MAE (média ± dp) | − Centralizado completo | sementes < 0 | IC95% t |
|---|---|---|---|---|
| Centralizado completo | 3,9416 ± 0,0071 | — | — | — |
| sem_arestas | 3,9629 ± 0,0181 | **+0,021** | 0/5 | [+0,003; +0,039] |
| cortes_k20 | 3,9469 ± 0,0266 | **+0,005** | 2/5 | [−0,024; +0,034] |
| cortes_k166 | 3,9308 ± 0,0143 | **−0,011** | 4/5 | [−0,025; +0,003] |
| FedAvg k=20 | 4,0739 ± 0,0420 | +0,132 | 0/5 | [+0,076; +0,189] |
| FedAvg k=166 | 4,3353 ± 0,0132 | +0,394 | 0/5 | [+0,373; +0,414] |

| contraste principal | Δ global | sementes < 0 | IC95% t |
|---|---|---|---|
| FedAvg k=20 − cortes_k20 | **+0,127 ± 0,060** | 0/5 | [+0,053; +0,201] |
| FedAvg k=166 − cortes_k166 | **+0,404 ± 0,024** | 0/5 | [+0,375; +0,434] |

### Fronteira e interior (estratos da própria partição)

| contraste | k | fronteira | interior | fronteira − interior (por semente) |
|---|---|---|---|---|
| sem_arestas − Centralizado | 20 | +0,057 (1/5 < 0) | +0,017 (0/5) | — |
| cortes_k20 − Centralizado | 20 | +0,003 ± 0,030 (2/5) [−0,034; +0,041] | +0,006 (3/5) | −0,002 ± 0,022; [−0,030; +0,026] |
| FedAvg − cortes_k20 | 20 | +0,252 ± 0,069 (0/5) | +0,112 (0/5) | +0,139 ± 0,041; 5/5 > 0; [+0,088; +0,190] |
| cortes_k166 − Centralizado | 166 | −0,014 ± 0,029 (4/5) [−0,049; +0,021] | −0,009 (5/5) | −0,005 ± 0,028; [−0,040; +0,030] |
| FedAvg − cortes_k166 | 166 | +0,756 ± 0,044 (0/5) | +0,206 (0/5) | +0,550 ± 0,034; 5/5 > 0; [+0,509; +0,592] |

### Faixas de perda de peso, volume e cobertura

- **cortes − Centralizado:** em nenhuma faixa de perda de peso, de vizinhança, de volume ou de cobertura,
  em k=20 ou k=166, o controle com cortes ficou consistentemente pior. As médias ficam entre −0,05 e
  +0,01, com sinais divididos ou favoráveis ao controle. Na faixa (0,50;1] de perda de vizinhança de
  k=166 (36 nós), −0,049 [−0,221; +0,122]; na mesma faixa de perda de peso (89 nós), −0,002 [−0,024; +0,020]. Em k=166 o controle ficou ligeiramente melhor no interior (−0,009, 5/5) e nos
  tercis médios; magnitudes pequenas.
- **sem_arestas − Centralizado (k=20):** o pequeno custo de remover todas as arestas aparece onde há
  mais volume e mais vizinhos: tercil alto de volume +0,057 [+0,006; +0,108], faixa (0;0,25] de perda de
  peso +0,096 [+0,030; +0,161]; tercis baixo e médio de volume ≈ 0.
- **FedAvg − cortes:** praticamente igual a FedAvg − Centralizado em todos os estratos (por exemplo, tercil
  alto de volume: +0,328 contra +0,331 em k=20; +0,973 contra +0,955 em k=166).

### Validação (robustez; a validação escolheu os checkpoints)

MAE global de validação: FedAvg − cortes +0,206 [+0,140; +0,271] (k=20) e +0,450 [+0,404; +0,495]
(k=166), 0/5 favoráveis ao FedAvg; cortes − Centralizado −0,007 [−0,110; +0,097] e −0,027 [−0,078;
+0,025], sementes divididas; sem_arestas − Centralizado +0,009 [−0,056; +0,074] (2/5 < 0). O benefício
líquido do grafo, já pequeno no teste, não aparece na validação. Fronteira − interior na validação:
FedAvg − cortes +0,396 (k=20) e +0,545 (k=166), 5/5 positivas.

## Respostas

1. **Qual o benefício líquido do grafo sob o protocolo?** *Observado:* pequeno. Retirar todas as arestas
   aumentou o MAE de teste em 0,021 embarques/h (cerca de 0,5 % do MAE), com as cinco sementes na mesma
   direção e IC [+0,003; +0,039]; na validação o efeito não aparece (+0,009 [−0,056; +0,074]). O custo no
   teste se concentra em nós de alto volume e na fronteira de k=20.
2. **Quanto o Centralizado depende das conexões entre clientes?** *Observado:* não detectamos
   dependência. Remover as 338 arestas cortadas por k=20 (3,6 % das arestas) ou as 1 334 cortadas por
   k=166 (14,3 %) não aumentou o MAE: +0,005 [−0,024; +0,034] e −0,011 [−0,025; +0,003], também na
   fronteira. Os intervalos são compatíveis com efeitos de até ~0,03–0,04 em qualquer sentido.
3. **Com disponibilidade de arestas correspondente, quanto resta da diferença do FedAvg?** *Observado:*
   quase toda. FedAvg − cortes é +0,127 (k=20) e +0,404 (k=166), praticamente igual a FedAvg −
   Centralizado (+0,132 e +0,394), e mantém a concentração na fronteira (fronteira − interior +0,139 e
   +0,550, 5/5). Essa diferença é 6× (k=20) e 19× (k=166) maior que o benefício líquido de todo o grafo.

## Interpretação plausível (não demonstrada)

- Sob este protocolo e esta arquitetura (LEConv de uma camada, janela de 168 h), a mensagem dos
  vizinhos agrega pouco à previsão de embarques, e as conexões entre clientes agregam ainda menos. Isso
  é compatível com o resultado nulo do halo, que repõe exatamente essas mensagens: haveria pouco a
  recuperar.
- A perda do FedAvg e sua concentração na fronteira **não** ficam explicadas pela falta das arestas
  cortadas, porque o controle centralizado sem essas arestas não as reproduz. Elas ficam associadas ao
  procedimento federado (atualizações locais, Adam reiniciado a cada rodada, agregação de clientes
  heterogêneos, orçamento de rodadas) e à composição dos estratos (a fronteira concentra nós de alto
  volume, como mostrou a análise estratificada). O contraste não isola qual desses elementos responde
  pela diferença.

## Questões em aberto e limitações

- O contraste FedAvg − cortes não separa causa única: centralizado e federado diferem em lotes,
  atualizações, reinício do otimizador, agregação, número de passos (600 épocas contra 600/1 000
  rodadas) e hardware. Não é decomposição causal aditiva.
- **Hardware:** cortes_k166 rodou inteiro na RTX 2060; o Centralizado e o FedAvg k=166, no Terumo (L40S e
  A16). O −0,011 de cortes_k166 − Centralizado pode conter efeito de máquina (não determinismo do CUDA);
  não interpretamos esse sinal como ganho. Os braços do Terumo repetiram, por semente, o tipo de GPU da
  referência. Tempos não são comparados entre máquinas.
- Uma partição por k (Leiden, semente 42); uma arquitetura; 5 sementes. Ausência de efeito detectável não
  é demonstração de ausência de efeito.
- O resultado vale para este grafo (`transit` simétrico, peso `log1p(contagem)`), este alvo e este
  modelo; outro grafo ou um modelo com mais camadas poderia usar mais a estrutura.

## Recomendação para o próximo experimento

Os controles deslocam a pergunta do **valor das mensagens** para o **procedimento federado**. O passo
mais informativo seria decompor a diferença FedAvg − cortes sem mudar o grafo, por exemplo um "FedAvg com
um único cliente" (todos os nós, mesmas rodadas, Adam reiniciado a cada rodada, uma época local), que
mede o efeito da estrutura de rodadas e do otimizador sem heterogeneidade entre clientes; e, separadamente,
o efeito do orçamento (o FedAvg k=166 escolheu checkpoints no fim das 1 000 rodadas). Personalização
continua como hipótese aberta para a heterogeneidade entre clientes. Nenhum desses experimentos foi
iniciado; a decisão fica com você.
