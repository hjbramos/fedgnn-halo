# Estado de lançamento — 14/11/2026

Servidor: `terumo`. Pasta isolada: `~/controles_20261114`.
Python: `/mnt/ssd1/helder/conda/envs/fl_env/bin/python`.
Código-base local: commit `2c3690e`, snapshot identificado em `source_manifest.json`. O script de liberação `scripts/completar_controles_20261114_gate.py` foi transferido adicionalmente após o snapshot.

A auditoria local e a do servidor coincidiram exatamente para séries, máscaras, adjacências, médias/desvios de padronização, origens de treino/validação/teste e atribuições das partições. Nenhuma partição avaliada tem nó sem entrada interna.

Foram iniciados os smokes nas GPUs 0 e 1. Os dois primeiros (SUNT k6 e k20, halo none) concluíram sem avaliação de teste. Os demais seguem em duas filas. A sessão `controles_gate_20261114` aguarda a conclusão e validação de todos os 13 smokes antes de liberar 65 treinos. O estado persistente é `logs/completar_controles_20261114/campaign_status.json` na pasta remota.

As filas completas são executadas pelo processo gate, limitado a dois subprocessos simultâneos. Se houver falha no smoke, a campanha completa não é liberada. Não relançar o gate enquanto houver processo ativo. Logs individuais ficam no mesmo diretório; resultados em `results/completar_controles_20261114` e smokes em `results/_smoke/completar_controles_20261114`.

Após conclusão: copiar resultados e procedência, auditar todas as células, conferir correspondência com comparadores, integrar ao exportador e só então atualizar o pacote validado e a dissertação. Nenhuma tabela da dissertação foi alterada para apresentar esses treinos como concluídos.

## Ampliação autorizada de paralelismo

Escalonador: `scripts/completar_controles_20261114_parallel.py`, sessão remota `controles_parallel_20261114`. Substitui as filas antigas sem reiniciar os trainers PID451052 (SUNT none k6 seed7) e PID451053 (SUNT none k20 seed7). Os despachantes antigos são suspensos individualmente, evitando lançamentos duplicados, e encerrados somente após ambos os treinos adotados terminarem.

Registros: `parallel_takeover.json` guarda os PIDs e hashes das configurações; `parallel.log` registra admissões e términos; `campaign_status.json` informa a situação e os processos ativos. No máximo cinco treinos, um por GPU, conforme emenda no protocolo. Não relançar um despachante antigo: isso duplicaria tarefas. Os arquivos de configuração científica não foram alterados.

## Escalonador vigente: dual_v3

Script `scripts/completar_controles_20261114_dual.py`, sessão `controles_dual_20261114`. Adota dinamicamente os processos científicos vivos, suspende somente o escalonador anterior e verifica exclusividade de cada par configuração/semente. `dual_takeover.json` registra os processos adotados e hashes das configurações; `dual.log` registra lançamentos/términos. `campaign_status.json` indica GPU, PID e recursos observados. O teto operacional pode ser reduzido em `dual_limits.json` sem reiniciar os treinos. As versões anteriores não devem ser retomadas.
