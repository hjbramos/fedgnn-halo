#!/usr/bin/env bash
# Piloto de orientação do grafo do SUNT (embarques, centralizado, SÓ validação): 5 sementes × 3 braços.
# Uma janela tmux por semente, presa a uma GPU, rodando os três braços em sequência (mesmo hardware dentro da
# semente). Determinismo estrito: CUBLAS_WORKSPACE_CONFIG e PYTHONHASHSEED exportados antes do processo.
# Uso (no Terumo, na raiz da worktree):  SESSION=piloto_direcao bash scripts/sunt_piloto_direcao.sh
#   SMOKE=1 MAX_EPOCHS=2 SEEDS=7 bash scripts/sunt_piloto_direcao.sh   → saída em results/_smoke/sunt_piloto_direcao
set -euo pipefail
SESSION=${SESSION:-piloto_direcao}
PY=${PY:-/mnt/ssd1/helder/conda/envs/fl_env/bin/python}
SEEDS=${SEEDS:-"7 42 101 123 314"}
declare -A GPU=([7]=0 [42]=1 [101]=2 [123]=3 [314]=4)   # semente → GPU (0 = L40S; 1–4 = A16)
TIMEOUT_H=${TIMEOUT_H:-9}                                  # por execução (só contra travamento)
if [ "${SMOKE:-0}" = 1 ]; then
  BASE=results/_smoke/sunt_piloto_direcao; EXTRA="--max-epochs ${MAX_EPOCHS:-2} --output"
else
  BASE=results/sunt_piloto_direcao; EXTRA=""
fi
LOG=$BASE/logs; mkdir -p "$LOG"
tmux has-session -t "$SESSION" 2>/dev/null && { echo "sessão $SESSION já existe: nada lançado" >&2; exit 1; }
{ echo "commit $(git rev-parse HEAD) dirty=[$(git status --porcelain --untracked-files=no)]"; date -u "+%F %T UTC"
  nvidia-smi --query-gpu=index,name,memory.used,utilization.gpu --format=csv,noheader; } > "$LOG/lancamento.txt"
tmux new-session -d -s "$SESSION" -n info "sleep infinity"
for s in $SEEDS; do
  g=${GPU[$s]}
  out_arg=""
  cmd="cd $(pwd); export CUDA_VISIBLE_DEVICES=$g CUBLAS_WORKSPACE_CONFIG=:4096:8 PYTHONHASHSEED=0; for b in simetrico observado invertido; do"
  if [ "${SMOKE:-0}" = 1 ]; then out_arg="$EXTRA $BASE/\$b"; fi
  cmd="$cmd echo \"\$(date -u +%FT%TZ) \$b início\" >> $LOG/seed${s}_rc.txt;"
  cmd="$cmd timeout --kill-after=60 ${TIMEOUT_H}h $PY -m experiments.train --dataset sunt --seed $s --config config/sunt_piloto_direcao_\$b.yaml --device cuda:0 --no-resume $out_arg > $LOG/seed${s}_\$b.log 2>&1;"
  cmd="$cmd rc=\$?; echo \"\$(date -u +%FT%TZ) \$b rc=\$rc\" >> $LOG/seed${s}_rc.txt; done; echo FIM >> $LOG/seed${s}_rc.txt; sleep infinity"
  tmux new-window -t "$SESSION" -n "s$s" "bash -c '$cmd'"
done
echo "sessão $SESSION: sementes [$SEEDS], logs em $LOG"
